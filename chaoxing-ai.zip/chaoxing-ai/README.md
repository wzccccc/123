# 超星答题 · 免卡密直连版（Xposed / LSPosed 模块）

模仿 `Xposed-Modules-Repo/com.yinshibai.chaoxingx`（学习通 考试击破）的实现思路重写：
功能一模一样，但**彻底去掉激活码 / 卡密 / 授权服务器校验**，装好填上自己的 API 就能跑。

| 能力 | 原模块 | 本项目 |
| --- | --- | --- |
| 激活码 | 需要卡密 + 联网验证 | 无，删掉了整套 license 逻辑 |
| 题库 | 有（导入/导出/缓存） | 有，走 ContentProvider 跨进程总线 |
| AI 作答 | 有（自填 API） | 有，OpenAI 兼容协议，DeepSeek / 通义 / 智谱 / one-api 全通吃 |
| 中文/英文 | 切换 | 切换 |
| 自动点选 | H5 + 原生 | H5 走 JS 注入，原生走 View 树遍历 |

---

## 1. 目录结构

```
chaoxing-ai/
├── settings.gradle.kts / build.gradle.kts / gradle.properties
├── app/
│   ├── build.gradle.kts
│   └── src/main/
│       ├── AndroidManifest.xml           Xposed 模块声明 + Provider + 三个界面
│       ├── assets/
│       │   ├── xposed_init               入口类名
│       │   └── inject.js                 H5 答题页注入脚本（MutationObserver 自愈）
│       ├── res/values/                   字符串 + 作用域数组
│       └── java/com/yinshibai/chaoxingx/free/
│           ├── MainHook.java             入口：Application.attach → 装三套 Hook
│           ├── Cfg.java                  XSharedPreferences 读配置
│           ├── Const.java                包名 / 关键字段 / 阈值（换版本只改这里）
│           ├── AppCtx.java               Context 反射兜底（AppGlobals 是 @hide）
│           ├── CxLog.java                日志（logcat + 环形缓冲 + 落盘）
│           ├── Question.java             题目模型
│           ├── Fuzzy.java                归一化 + Dice 相似度（题库模糊匹配）
│           ├── Prompt.java               提示词模板 + ANSWER 抽取
│           ├── AiClient.java             OpenAI 兼容 Chat Completions
│           ├── AnswerResolver.java       答案决策链：内存 → 题库 → AI → 回写
│           ├── BankStore.java            题库客户端
│           ├── BankProvider.java         题库/日志跨进程总线
│           ├── Assets.java               跨包读模块 assets
│           ├── hooks/
│           │   ├── NetHook.java          拦 OkHttp，提前预解题
│           │   ├── PayloadScanner.java   字段白名单递归扫 JSON，泛化提题
│           │   ├── WebHook.java          WebView 注入 + JS 桥
│           │   └── NativeHook.java       原生页 View 树识别与点选
│           └── ui/
│               ├── SettingsActivity.java 主配置（无卡密区块）
│               ├── BankActivity.java     题库导入/导出/清空
│               └── LogActivity.java      日志查看
└── docs/REVERSE.md                       换版本时怎么重新定位 Hook 点
```

---

## 2. 构建

需要 JDK 17 + Android SDK（compileSdk 34）。

```bash
cd chaoxing-ai
# app/build.gradle.kts 里 release 已直接挂 debug 签名，侧载无需自建 keystore
./gradlew assembleRelease
# 产物：app/build/outputs/apk/release/app-release.apk
```

没有本地 Android SDK？把目录推到 GitHub，仓库自带的
`.github/workflows/build-apk.yml` 会云构建，产物在 Actions → Artifacts 里下载。

没有 gradle wrapper 时先 `gradle wrapper --gradle-version 8.7`，或用 Android Studio 直接打开本目录。

---

## 3. 安装与启用

> 完整图文流程（含 LSPosed 配置、GitHub Actions 云构建、报错对照表、卸载回滚）见
> **[docs/INSTALL.md](docs/INSTALL.md)**。这里只放最短路径。

1. 安装 APK（LSPosed 模块列表里能看到「超星答题·免卡密」）。
2. 打开模块 → 填 **Base URL / API Key / 模型名** → 保存 → 点「测试连通性」。
   - DeepSeek：`https://api.deepseek.com/v1` + `deepseek-chat`
   - 通义：`https://dashscope.aliyuncs.com/compatible-mode/v1` + `qwen-plus`
   - Ollama 本地：`http://127.0.0.1:11434/v1` + `qwen2.5:7b`
3. LSPosed → 模块 → 勾选作用域 **学习通（com.chaoxing.mobile）**。
4. 强行停止学习通再打开（模块在进程启动时加载）。

---

## 4. 答题链路（和原模块一致）

```
             ┌──────────── OkHttp 拦截（预解题）
页面请求  ───┤
             └──────────── H5 注入 / 原生 View 遍历
                                │
                                ▼
                     AnswerResolver.resolve(q)
                     ① 内存缓存（300 条 LRU）
                     ② 本地题库（Dice ≥ 0.88 命中）
                     ③ AI（ANSWER: X 严格格式）
                     ④ 回写题库 + 内存
                                │
                                ▼
                 点选：JS click() / View.performClick()
```

- **预解题**：网络层先把整页题目丢给 AI 并行求解，UI 填空时直接命中缓存，做到“翻到即答”。
- **题库建议模式**：和原模块的「题库答案作为 AI 提示词（不直接作答）」一致，勾上后题库只作为 AI 的参考，最终答案由模型给出。
- **多选/判断/填空**：AI 输出 `ANSWER: ACD` / `ANSWER: 对` / 文本，`Prompt.extract` 统一归一化，`AnswerResolver.mapToOptions` 再映射到选项下标。

---

## 5. 与原模块的差异（重点）

1. **卡密整块删除**：没有 `activation`/`license`/`cardKey` 类，没有心跳校验，没有服务器时间比对；`SettingsActivity` 顶部只显示「运行中 / 未配置 Key」。
2. **配置不再加密**：原版用卡密派生密钥保护 API Key，这里直接存 SharedPreferences（`cxai_free`），由 LSPosed 的 `xposedsharedprefs` 让被 Hook 进程可读。
3. **题库总线换成 ContentProvider**：原版直接读写 sdcard，Android 11+ 会失败；这里用 `content://com.yinshibai.chaoxingx.free.bank` 走 IPC，两端都能读写。
4. **Hook 点全部去硬编码**：原版写死了若干混淆类名，版本一更新就失效；这里 OkHttp/WebView 用框架级通用点，原生页不依赖类名，只靠 View 结构特征。

---

## 6. 已知限制

- 考试页若开启「禁止切屏/防作弊」的服务器端校验，本模块不处理（原模块同样不处理），这类页面建议只用题库预览手动作答。
- H5 页面 DOM 结构随版本变化，`inject.js` 顶部的 `CFG.block / CFG.option / CFG.stem` 三个选择器数组就是给你改的。
- 原生页识别是启发式的：同一个界面里如果同时存在多组「≥2 个可点文本控件」，可能选错组，用日志确认（`日志` 界面能看到「原生页已作答 …」）。
- 只处理 UI 点选，**不做接口级交卷**：交卷/提交仍由学习通自身逻辑完成，避免踩到签名校验。

换学习通版本后重定位 Hook 点的流程见 [docs/REVERSE.md](docs/REVERSE.md)。
安全对比（原版 vs 本版、已修漏洞、剩余风险）见 [docs/SECURITY.md](docs/SECURITY.md)。
检测与隐藏对比（栈/路径/包名/maps/isTrusted/Provider 指纹）见 [docs/DETECTION.md](docs/DETECTION.md)。
学习通升级时要不要停模块、怎么验证见 [docs/UPDATE.md](docs/UPDATE.md)。

---

## 7. 安全现状（v1.0.1）

| 项 | 状态 |
| --- | --- |
| 题库 Provider | exported，但内置 UID 白名单（仅模块自身 + 学习通），越权访问被拒 |
| 题库入库 | 题干 ≤2000 字、答案 ≤500 字、总量 ≤20000 条 |
| WebView JS 桥 | 域名严格后缀匹配，禁 `file://`/`data://`，仿冒域拿不到桥 |
| 传输 | 只允许 `https://`；`http://` 仅本地模型（127.0.0.1 / 10.x / 192.168.x） |
| 权限 | 仅 `INTERNET` + `ACCESS_NETWORK_STATE`，无存储权限 |
| API Key | **仍是明文** SharedPreferences（待接 Android Keystore） |
| 反检测 | 栈过滤 / 13 条路径隐藏 / 包名隐藏（`StealthHook`）；JS 桥随机名；点击随机延时 |
| 版本闸门 | 学习通 versionCode 变化即自动降级「提示模式」，只给答案不点选（`VersionGate`） |
| 未覆盖 | `/proc/self/maps`（需 Shamiko）、`event.isTrusted`、Provider authority 可探测 |


plugins {
    id("com.android.application")
}

android {
    namespace = "com.yinshibai.chaoxingx.free"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.yinshibai.chaoxingx.free"
        minSdk = 24
        targetSdk = 34
        versionCode = 4
        versionName = "1.0.3-free"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            // 侧载方便：直接用 debug 签名，无需自己生成 keystore
            signingConfig = signingConfigs.getByName("debug")
        }
        debug {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    packaging {
        resources.excludes += setOf("META-INF/**", "kotlin/**")
    }

    lint {
        abortOnError = false
    }
}

dependencies {
    // Xposed API：只编译期使用，运行期由框架提供。
    // 若 api.xposed.info 拉不动，把 api-82.jar 放到 app/libs/ 下即可自动走本地兜底。
    val localApi = file("libs/api-82.jar")
    if (localApi.exists()) {
        compileOnly(files(localApi))
    } else {
        compileOnly("de.robv.android.xposed:api:82")
    }
}

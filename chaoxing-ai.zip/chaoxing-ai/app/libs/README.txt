把 Xposed API 放到这个目录可以离线构建：

  api-82.jar

下载地址：
  https://api.xposed.info/de/robv/android/xposed/api/82/api-82.jar

app/build.gradle.kts 会自动检测：存在 app/libs/api-82.jar 就走本地文件，
否则从 api.xposed.info 拉取。

-keep class com.yinshibai.chaoxingx.free.** { *; }
-keep class de.robv.android.xposed.** { *; }
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

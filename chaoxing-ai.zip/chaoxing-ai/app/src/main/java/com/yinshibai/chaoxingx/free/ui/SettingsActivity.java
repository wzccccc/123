package com.yinshibai.chaoxingx.free.ui;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.yinshibai.chaoxingx.free.AiClient;
import com.yinshibai.chaoxingx.free.BankStore;
import com.yinshibai.chaoxingx.free.Cfg;
import com.yinshibai.chaoxingx.free.VersionGate;

/** 主配置界面：没有激活码/卡密，全部功能直接可用 */
public class SettingsActivity extends Activity {

    private EditText etBase, etKey, etModel;
    private CheckBox cbAuto, cbBankFirst, cbHint, cbCache, cbNext, cbLog, cbStealth, cbDry;
    private TextView tvStatus, tvBankInfo, tvLang, tvVersion;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = column();
        int pad = dp(16);
        root.setPadding(pad, pad, pad, pad);
        scroll.addView(root, new ViewGroup.LayoutParams(-1, -2));
        setContentView(scroll);

        TextView title = text("超星答题 · 免卡密直连", 22, Color.parseColor("#111111"));
        title.setGravity(Gravity.CENTER);
        root.addView(title);

        tvStatus = text("运行中", 14, Color.WHITE);
        tvStatus.setGravity(Gravity.CENTER);
        tvStatus.setBackground(round(Color.parseColor("#2FA84F"), dp(8)));
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-2, -2);
        sp.gravity = Gravity.CENTER_HORIZONTAL;
        sp.topMargin = dp(10);
        tvStatus.setPadding(dp(22), dp(8), dp(22), dp(8));
        root.addView(tvStatus, sp);

        // ---------------- 版本闸门 ----------------
        tvVersion = text(VersionGate.describe(this), 12, Color.parseColor("#666666"));
        tvVersion.setPadding(0, dp(10), 0, 0);
        root.addView(tvVersion);

        Button adapt = button("标记为「当前版本已适配」");
        root.addView(adapt);
        adapt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int code = VersionGate.codeOf(SettingsActivity.this);
                if (code <= 0) {
                    toast("未检测到学习通");
                    return;
                }
                prefs().edit().putString(Cfg.K_VERIFIED_VER, String.valueOf(code)).apply();
                tvVersion.setText(VersionGate.describe(SettingsActivity.this));
                toast("已适配 v" + code + "，重启学习通后允许真实点选");
            }
        });

        // ---------------- API 配置 ----------------
        root.addView(section("API 配置（OpenAI 兼容）"));
        etBase = input("Base URL，如 https://api.deepseek.com/v1",
                Cfg.s(Cfg.K_BASE, Cfg.DEF_BASE), false);
        root.addView(etBase);
        etKey = input("API Key（sk-...）", Cfg.s(Cfg.K_KEY, ""), true);
        root.addView(etKey);
        etModel = input("模型名，如 deepseek-chat / qwen-plus / gpt-4o-mini",
                Cfg.s(Cfg.K_MODEL, Cfg.DEF_MODEL), false);
        root.addView(etModel);

        Button saveBtn = button("保存配置");
        root.addView(saveBtn);
        saveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                save();
                toast("已保存，重启学习通生效");
                tvStatus.setText(Cfg.s(Cfg.K_KEY, "").length() > 0 ? "运行中" : "未配置 Key");
            }
        });

        Button test = button("测试连通性");
        root.addView(test);
        test.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                save();
                toast("正在请求模型…");
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        String msg;
                        try {
                            msg = AiClient.ping();
                        } catch (Throwable t) {
                            msg = "失败: " + t.getClass().getSimpleName() + " " + t.getMessage();
                        }
                        final String out = msg;
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                toast(out);
                            }
                        });
                    }
                }).start();
            }
        });

        // ---------------- 功能开关 ----------------
        root.addView(section("答题策略"));
        cbAuto = check("启用自动答题（总开关）", Cfg.b(Cfg.K_AUTO, true));
        cbBankFirst = check("题库答案直接作答（关闭则由 AI 决定）", Cfg.b(Cfg.K_BANK_FIRST, true));
        cbHint = check("题库答案作为 AI 提示词（不直接作答）", Cfg.b(Cfg.K_HINT_MODE, true));
        cbCache = check("启用本地缓存（自动把 AI 结果存进题库）", Cfg.b(Cfg.K_CACHE, true));
        cbNext = check("答完自动点「下一题」", Cfg.b("auto_next", false));
        cbLog = check("记录运行日志", Cfg.b(Cfg.K_LOG, true));
        root.addView(cbAuto);
        root.addView(cbBankFirst);
        root.addView(cbHint);
        root.addView(cbCache);
        root.addView(cbNext);
        root.addView(cbLog);

        cbStealth = check("反检测（栈过滤 / 路径隐藏 / 包名隐藏）", Cfg.b(Cfg.K_STEALTH, true));
        root.addView(cbStealth);

        cbDry = check("提示模式（只记录答案，不自动点选）", Cfg.b(Cfg.K_DRY_RUN, false));
        root.addView(cbDry);

        // ---------------- 语言 ----------------
        root.addView(section("Language / 语言"));
        tvLang = text(langLabel(), 15, Color.parseColor("#333333"));
        tvLang.setPadding(0, dp(8), 0, dp(8));
        tvLang.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean zh = !"en".equalsIgnoreCase(Cfg.s(Cfg.K_LANG, "zh"));
                prefs().edit().putString(Cfg.K_LANG, zh ? "en" : "zh").apply();
                tvLang.setText(langLabel());
                toast("已切换，重启学习通生效");
            }
        });
        root.addView(tvLang);

        // ---------------- 题库 ----------------
        root.addView(section("题库"));
        tvBankInfo = text("", 14, Color.parseColor("#555555"));
        root.addView(tvBankInfo);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        Button manage = button("管理题库");
        Button clear = button("清空");
        row.addView(manage, weight());
        row.addView(clear, weight());
        root.addView(row);

        manage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(SettingsActivity.this, BankActivity.class));
            }
        });
        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int n = BankStore.clear();
                refreshBank();
                toast("已清空 " + n + " 条");
            }
        });

        // ---------------- 其他 ----------------
        root.addView(section("其他"));
        Button logBtn = button("查看运行日志");
        root.addView(logBtn);
        logBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(SettingsActivity.this, LogActivity.class));
            }
        });

        TextView tip = text("使用步骤：1) 填 Base URL / Key / 模型并保存  2) LSPosed 里勾选「学习通」作用域并重启学习通  "
                + "3) 打开答题页即可自动作答。本版本不含任何卡密校验。", 12, Color.parseColor("#888888"));
        tip.setPadding(0, dp(14), 0, dp(8));
        root.addView(tip);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshBank();
        if (tvVersion != null) tvVersion.setText(VersionGate.describe(this));
        boolean configured = Cfg.s(Cfg.K_KEY, "").length() > 0;
        tvStatus.setText(configured ? "运行中" : "未配置 Key");
    }

    private void refreshBank() {
        int n = BankStore.count();
        tvBankInfo.setText("本地题库 " + n + " 条 · 命中阈值 " + (int) (com.yinshibai.chaoxingx.free.Const.BANK_SIM * 100) + "%");
    }

    private String langLabel() {
        boolean zh = !"en".equalsIgnoreCase(Cfg.s(Cfg.K_LANG, "zh"));
        return zh ? "中文  ▼  点击切换为英文" : "English  ▼  点按切换为中文";
    }

    private void save() {
        prefs().edit()
                .putString(Cfg.K_BASE, etBase.getText().toString().trim())
                .putString(Cfg.K_KEY, etKey.getText().toString().trim())
                .putString(Cfg.K_MODEL, etModel.getText().toString().trim())
                .putBoolean(Cfg.K_AUTO, cbAuto.isChecked())
                .putBoolean(Cfg.K_BANK_FIRST, cbBankFirst.isChecked())
                .putBoolean(Cfg.K_HINT_MODE, cbHint.isChecked())
                .putBoolean(Cfg.K_CACHE, cbCache.isChecked())
                .putBoolean("auto_next", cbNext.isChecked())
                .putBoolean(Cfg.K_LOG, cbLog.isChecked())
                .putBoolean(Cfg.K_STEALTH, cbStealth.isChecked())
                .putBoolean(Cfg.K_DRY_RUN, cbDry.isChecked())
                .apply();
    }

    private android.content.SharedPreferences prefs() {
        return getSharedPreferences(Cfg.PREFS, MODE_PRIVATE);
    }

    // ------------------------------------------------------------- UI 小工具

    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private TextView section(String s) {
        TextView tv = text(s, 16, Color.parseColor("#1976D2"));
        tv.setPadding(0, dp(20), 0, dp(6));
        return tv;
    }

    private TextView text(String s, int sp, int color) {
        TextView tv = new TextView(this);
        tv.setText(s);
        tv.setTextSize(sp);
        tv.setTextColor(color);
        return tv;
    }

    private EditText input(String hint, String value, boolean secret) {
        EditText et = new EditText(this);
        et.setHint(hint);
        et.setText(value);
        et.setTextSize(14);
        et.setSingleLine(true);
        et.setPadding(dp(10), dp(10), dp(10), dp(10));
        et.setBackground(round(Color.parseColor("#F2F3F5"), dp(8)));
        if (secret) et.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        et.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        return et;
    }

    private CheckBox check(String s, boolean checked) {
        CheckBox cb = new CheckBox(this);
        cb.setText(s);
        cb.setTextSize(14);
        cb.setChecked(checked);
        cb.setPadding(0, dp(6), 0, dp(6));
        return cb;
    }

    private Button button(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextSize(14);
        return b;
    }

    private LinearLayout.LayoutParams weight() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
        lp.setMargins(dp(4), 0, dp(4), 0);
        return lp;
    }

    private GradientDrawable round(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(radius);
        return d;
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }
}

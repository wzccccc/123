package com.yinshibai.chaoxingx.free;

import android.util.Log;

import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.Date;
import java.util.Locale;

/** 统一日志：logcat + 内存环形缓冲 + 跨进程落盘（供模块界面查看） */
public final class CxLog {
    private static final String TAG = "CxAiFree";
    private static final int MAX = 400;
    private static final ArrayDeque<String> RING = new ArrayDeque<>();
    private static final SimpleDateFormat FMT = new SimpleDateFormat("HH:mm:ss", Locale.US);
    private static volatile boolean toProvider = true;

    private CxLog() {}

    public static void i(String msg) {
        Log.i(TAG, msg);
        push("I", msg);
    }

    public static void w(String msg) {
        Log.w(TAG, msg);
        push("W", msg);
    }

    public static void e(String msg, Throwable t) {
        Log.e(TAG, msg, t);
        push("E", msg + (t == null ? "" : " :: " + t.getClass().getSimpleName() + " " + t.getMessage()));
    }

    public static void setProviderEnabled(boolean v) {
        toProvider = v;
    }

    private static void push(String lv, String msg) {
        String line;
        synchronized (RING) {
            line = FMT.format(new Date()) + " " + lv + " " + msg;
            RING.addLast(line);
            while (RING.size() > MAX) RING.removeFirst();
        }
        if (!toProvider) return;
        try {
            BankStore.log(line);
        } catch (Throwable ignored) {
            toProvider = false; // 避免 provider 不可用时反复失败刷屏
        }
    }

    public static String dump() {
        StringBuilder sb = new StringBuilder();
        synchronized (RING) {
            for (String s : RING) sb.append(s).append('\n');
        }
        return sb.toString();
    }
}

package com.yinshibai.chaoxingx.free;

import android.content.Context;
import android.content.pm.PackageInfo;

/**
 * 版本闸门：学习通升级后，旧 Hook 点可能已失效，此时继续「自动点选」有误点风险
 * （极端情况会把「提交/交卷」当成选项点掉）。
 *
 * 策略：只有用户在当前版本上明确点过「本版本已适配」，才允许真实点选；
 * 否则自动降级为「提示模式」——照样求解、照样写日志，但不碰 UI。
 */
public final class VersionGate {
    private VersionGate() {}

    private static volatile boolean ready = false;
    private static volatile boolean dryRun = true;
    private static volatile boolean verified = false;
    private static volatile int code = -1;
    private static volatile String name = "";

    public static synchronized void check(Context ctx) {
        if (ctx == null) return;
        try {
            PackageInfo pi = ctx.getPackageManager().getPackageInfo(Const.TARGET, 0);
            code = pi.versionCode;
            name = pi.versionName == null ? "" : pi.versionName;
        } catch (Throwable t) {
            CxLog.e("读取目标版本失败", t);
        }
        String confirmed = Cfg.s(Cfg.K_VERIFIED_VER, "");
        verified = code > 0 && String.valueOf(code).equals(confirmed);
        dryRun = Cfg.b(Cfg.K_DRY_RUN, false) || !verified;
        ready = true;
        CxLog.i("目标版本 " + name + "(" + code + ") 已适配=" + verified
                + " 提示模式=" + dryRun);
    }

    public static boolean dryRun() {
        return dryRun;
    }

    public static boolean verified() {
        return verified;
    }

    public static int code() {
        return code;
    }

    public static String name() {
        return name;
    }

    public static boolean ready() {
        return ready;
    }

    /** 界面侧用：读取目标 App 版本（不依赖 Hook 进程） */
    public static String describe(Context ctx) {
        try {
            PackageInfo pi = ctx.getPackageManager().getPackageInfo(Const.TARGET, 0);
            String confirmed = ctx.getSharedPreferences(Cfg.PREFS, Context.MODE_PRIVATE)
                    .getString(Cfg.K_VERIFIED_VER, "");
            boolean ok = String.valueOf(pi.versionCode).equals(confirmed);
            return "学习通 " + pi.versionName + " (" + pi.versionCode + ") · "
                    + (ok ? "已适配，可真实点选" : "未适配 → 当前为提示模式");
        } catch (Throwable t) {
            return "未安装学习通或读取失败";
        }
    }

    public static int codeOf(Context ctx) {
        try {
            return ctx.getPackageManager().getPackageInfo(Const.TARGET, 0).versionCode;
        } catch (Throwable t) {
            return -1;
        }
    }
}

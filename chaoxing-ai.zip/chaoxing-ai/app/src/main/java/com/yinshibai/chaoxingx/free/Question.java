package com.yinshibai.chaoxingx.free;

import java.util.ArrayList;
import java.util.List;

/** 一道题：题干 + 选项 + 题型 */
public class Question {
    public String id = "";
    public String stem = "";
    /** single | multi | judge | fill | unknown */
    public String type = "unknown";
    public final List<String> keys = new ArrayList<>();
    public final List<String> options = new ArrayList<>();
    public String source = "net";
    /** 题库条目的答案（仅题库侧使用） */
    public String answer = "";
    public long createdAt = System.currentTimeMillis();

    public boolean valid() {
        return stem != null && Fuzzy.norm(stem).length() >= 4;
    }

    public String promptBody() {
        StringBuilder sb = new StringBuilder();
        sb.append(stem == null ? "" : stem.trim()).append('\n');
        for (int i = 0; i < options.size(); i++) {
            String k = i < keys.size() && keys.get(i) != null && keys.get(i).length() > 0
                    ? keys.get(i) : String.valueOf((char) ('A' + i));
            sb.append(k).append(". ").append(options.get(i)).append('\n');
        }
        if (options.isEmpty()) sb.append("(无选项，填空/简答题)\n");
        return sb.toString();
    }

    @Override
    public String toString() {
        return "Question{" + type + ", opts=" + options.size() + ", " + stem + "}";
    }
}

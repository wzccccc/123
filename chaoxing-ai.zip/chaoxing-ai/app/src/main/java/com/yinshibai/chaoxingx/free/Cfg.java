package com.yinshibai.chaoxingx.free;

import de.robv.android.xposed.XSharedPreferences;

/** 配置读写：模块界面写 SharedPreferences，Hook 侧用 XSharedPreferences 读 */
public final class Cfg {
    public static final String PREFS = "cxai_free";

    public static final String K_BASE = "ai_base";
    public static final String K_KEY = "ai_key";
    public static final String K_MODEL = "ai_model";
    public static final String K_TEMP = "ai_temp";
    public static final String K_PROMPT = "prompt_extra";
    public static final String K_AUTO = "auto_answer";
    public static final String K_BANK_FIRST = "bank_first";
    public static final String K_CACHE = "bank_cache";
    public static final String K_HINT_MODE = "bank_as_prompt";
    public static final String K_LANG = "lang";
    public static final String K_TIMEOUT = "timeout_s";
    public static final String K_SCROLL_NEXT = "auto_next";
    public static final String K_LOG = "log_enabled";
    public static final String K_STEALTH = "stealth";
    public static final String K_DRY_RUN = "dry_run";
    public static final String K_VERIFIED_VER = "verified_version";

    public static final String DEF_BASE = "https://api.deepseek.com/v1";
    public static final String DEF_MODEL = "deepseek-chat";

    private static volatile XSharedPreferences sp;
    private static volatile long lastLoad = 0L;

    private Cfg() {}

    public static synchronized void init() {
        if (sp == null) {
            try {
                sp = new XSharedPreferences(Const.MODULE_PKG, PREFS);
                sp.makeWorldReadable();
            } catch (Throwable t) {
                CxLog.e("XSharedPreferences init failed", t);
            }
        }
        if (sp != null) sp.reload();
    }

    /** 每次读取前 2 秒节流 reload，避免高频 IO */
    private static XSharedPreferences ref() {
        if (sp == null) init();
        if (sp != null && System.currentTimeMillis() - lastLoad > 2000L) {
            sp.reload();
            lastLoad = System.currentTimeMillis();
        }
        return sp;
    }

    public static String s(String key, String def) {
        try {
            XSharedPreferences p = ref();
            if (p == null) return def;
            String v = p.getString(key, null);
            return (v == null || v.length() == 0) ? def : v;
        } catch (Throwable t) {
            return def;
        }
    }

    public static boolean b(String key, boolean def) {
        try {
            XSharedPreferences p = ref();
            return p == null ? def : p.getBoolean(key, def);
        } catch (Throwable t) {
            return def;
        }
    }

    public static float f(String key, float def) {
        try {
            XSharedPreferences p = ref();
            return p == null ? def : p.getFloat(key, def);
        } catch (Throwable t) {
            return def;
        }
    }

    public static int i(String key, int def) {
        try {
            XSharedPreferences p = ref();
            if (p == null) return def;
            try {
                return p.getInt(key, def);
            } catch (Throwable cast) {
                return Integer.parseInt(p.getString(key, String.valueOf(def)));
            }
        } catch (Throwable t) {
            return def;
        }
    }

    public static boolean autoOn() {
        return b(K_AUTO, true);
    }

    public static boolean bankFirst() {
        return b(K_BANK_FIRST, true);
    }

    public static boolean cacheOn() {
        return b(K_CACHE, true);
    }

    public static boolean hintMode() {
        return b(K_HINT_MODE, true);
    }
}

package com.yinshibai.chaoxingx.free.ui;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.yinshibai.chaoxingx.free.Const;

/** 运行日志查看（日志由学习通进程写入 Provider，这里只读） */
public class LogActivity extends Activity {

    private TextView body;
    private ScrollView scroll;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(12);
        root.setPadding(pad, pad, pad, pad);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        Button refresh = new Button(this);
        refresh.setText("刷新");
        refresh.setAllCaps(false);
        Button share = new Button(this);
        share.setText("分享");
        share.setAllCaps(false);
        Button clear = new Button(this);
        clear.setText("清空");
        clear.setAllCaps(false);
        row.addView(refresh, weight());
        row.addView(share, weight());
        row.addView(clear, weight());
        root.addView(row);

        scroll = new ScrollView(this);
        body = new TextView(this);
        body.setTextSize(11);
        body.setTypeface(Typeface.MONOSPACE);
        body.setTextColor(Color.parseColor("#222222"));
        scroll.addView(body);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));
        setContentView(root);

        refresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                load();
            }
        });
        share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain");
                i.putExtra(Intent.EXTRA_TEXT, body.getText().toString());
                startActivity(Intent.createChooser(i, "分享日志"));
            }
        });
        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getContentResolver().delete(Uri.parse("content://" + Const.AUTHORITY + "/entry"), "logs", null);
                load();
                Toast.makeText(LogActivity.this, "已清空", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        load();
    }

    private void load() {
        StringBuilder sb = new StringBuilder();
        Cursor c = null;
        try {
            c = getContentResolver().query(Uri.parse("content://" + Const.AUTHORITY + "/logs"), null, null, null, null);
            if (c != null) {
                while (c.moveToNext()) sb.append(c.getString(0)).append('\n');
            }
        } catch (Throwable t) {
            sb.append("读取失败: ").append(t);
        } finally {
            if (c != null) c.close();
        }
        body.setText(sb.length() == 0 ? "暂无日志。先重启学习通让模块加载。" : sb.toString());
        scroll.post(new Runnable() {
            @Override
            public void run() {
                scroll.fullScroll(View.FOCUS_DOWN);
            }
        });
    }

    private LinearLayout.LayoutParams weight() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
        lp.setMargins(dp(3), 0, dp(3), 0);
        return lp;
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }
}

package com.yinshibai.chaoxingx.free;

/** 文本归一化与相似度（题库模糊匹配用，不引入任何第三方依赖） */
public final class Fuzzy {
    private Fuzzy() {}

    public static String norm(String s) {
        if (s == null) return "";
        StringBuilder sb = new StringBuilder(s.length());
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (Character.isWhitespace(c) || c == '\u00a0' || c == '\u3000') continue;
            if (isPunct(c)) continue;
            sb.append(Character.toLowerCase(c));
        }
        return sb.toString();
    }

    private static boolean isPunct(char c) {
        switch (c) {
            case '，': case '。': case '；': case '：': case '、': case '？': case '！':
            case ',': case '.': case ';': case ':': case '?': case '!':
            case '"': case '\'': case '“': case '”': case '‘': case '’':
            case '（': case '）': case '(': case ')': case '【': case '】':
            case '[': case ']': case '《': case '》': case '<': case '>':
            case '/': case '\\': case '|': case '~': case '`': case '^':
            case '*': case '+': case '=': case '_': case '-':
                return true;
            default:
                return false;
        }
    }

    /** Dice 系数（bigram），0~1 */
    public static double sim(String a, String b) {
        String x = norm(a);
        String y = norm(b);
        if (x.isEmpty() || y.isEmpty()) return 0d;
        if (x.equals(y)) return 1d;
        if (x.length() < 2 || y.length() < 2) return 0d;
        java.util.HashMap<String, Integer> bag = new java.util.HashMap<>();
        for (int i = 0; i < x.length() - 1; i++) {
            String g = x.substring(i, i + 2);
            bag.put(g, bag.containsKey(g) ? bag.get(g) + 1 : 1);
        }
        int hit = 0;
        for (int i = 0; i < y.length() - 1; i++) {
            String g = y.substring(i, i + 2);
            Integer n = bag.get(g);
            if (n != null && n > 0) {
                hit++;
                bag.put(g, n - 1);
            }
        }
        int total = (x.length() - 1) + (y.length() - 1);
        return total <= 0 ? 0d : (2.0 * hit) / total;
    }
}

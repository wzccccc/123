package com.yinshibai.chaoxingx.free.hooks;

import android.app.Activity;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.RadioButton;
import android.widget.TextView;

import com.yinshibai.chaoxingx.free.AnswerResolver;
import com.yinshibai.chaoxingx.free.Cfg;
import com.yinshibai.chaoxingx.free.Const;
import com.yinshibai.chaoxingx.free.CxLog;
import com.yinshibai.chaoxingx.free.Fuzzy;
import com.yinshibai.chaoxingx.free.Question;
import com.yinshibai.chaoxingx.free.VersionGate;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedHelpers;

/**
 * 原生答题页兜底方案：不依赖具体 View 类型，
 * 直接遍历当前 Activity 的 View 树，靠结构特征识别「题干 + 选项组」，
 * 求解后 performClick 点选。
 */
public final class NativeHook {
    private NativeHook() {}

    private static volatile boolean installed = false;
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static final Map<Integer, String> LAST_STEM = new HashMap<>();
    private static long lastScan = 0L;

    public static void install(ClassLoader cl) {
        if (installed) return;
        installed = true;
        try {
            XposedHelpers.findAndHookMethod(Activity.class, "onResume", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    schedule((Activity) param.thisObject, 800L);
                }
            });
            XposedHelpers.findAndHookMethod(Activity.class, "onWindowFocusChanged", boolean.class, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    if (Boolean.TRUE.equals(param.args[0])) schedule((Activity) param.thisObject, 1200L);
                }
            });
            CxLog.i("原生页兜底已安装");
        } catch (Throwable t) {
            CxLog.e("NativeHook 安装失败", t);
        }
    }

    private static void schedule(final Activity act, long delay) {
        if (act == null) return;
        MAIN.postDelayed(new Runnable() {
            @Override
            public void run() {
                try {
                    scan(act);
                } catch (Throwable t) {
                    CxLog.e("原生页扫描异常", t);
                }
            }
        }, delay);
    }

    // ------------------------------------------------------------- 扫描逻辑

    private static void scan(Activity act) {
        if (!Cfg.autoOn()) return;
        long now = System.currentTimeMillis();
        if (now - lastScan < 900L) return;
        lastScan = now;

        View root;
        try {
            root = act.getWindow() == null ? null : act.getWindow().getDecorView();
        } catch (Throwable t) {
            return;
        }
        if (root == null) return;

        List<View> views = new ArrayList<>();
        collect(root, views, 0);

        Map<ViewGroup, List<View>> groups = new LinkedHashMap<>();
        for (View v : views) {
            if (!looksLikeOption(v)) continue;
            ViewParent p = v.getParent();
            if (!(p instanceof ViewGroup)) continue;
            List<View> list = groups.get(p);
            if (list == null) {
                list = new ArrayList<>();
                groups.put((ViewGroup) p, list);
            }
            list.add(v);
        }

        List<View> best = null;
        for (Map.Entry<ViewGroup, List<View>> e : groups.entrySet()) {
            List<View> g = e.getValue();
            if (g.size() < 2) continue;
            if (best == null || g.size() > best.size()) best = g;
        }
        if (best == null) return;
        if (best.size() > 12) return; // 明显不是选项组（比如列表页）

        Collections.sort(best, new Comparator<View>() {
            @Override
            public int compare(View a, View b) {
                return Integer.compare(a.getTop(), b.getTop());
            }
        });

        List<View> viable = new ArrayList<>();
        List<String> texts = new ArrayList<>();
        for (View v : best) {
            String t = textOf(v);
            if (t.length() == 0 || t.length() > 200) continue;
            viable.add(v);
            texts.add(t);
        }
        if (texts.size() < 2) return;
        best = viable; // 选项与视图一一对应，防止下标错位

        String stem = findStem(views, best);
        if (stem == null || Fuzzy.norm(stem).length() < 4) return;

        String key = Fuzzy.norm(stem);
        String mark = act.getClass().getName() + "#" + System.identityHashCode(best.get(0).getParent());
        String last = LAST_STEM.get(mark.hashCode());
        if (key.equals(last)) return;

        Question q = new Question();
        q.stem = stem;
        q.source = "native";
        for (int i = 0; i < texts.size(); i++) {
            q.options.add(texts.get(i));
            q.keys.add(String.valueOf((char) ('A' + i)));
        }
        q.type = guessType(best);
        LAST_STEM.put(mark.hashCode(), key);

        final List<View> group = best;
        final String stemFinal = stem;

        // 主线程绝不发网络：命中缓存直接点，否则异步求解后回主线程点
        String cached = AnswerResolver.peek(stem);
        if (cached != null) {
            applyAnswer(act, q, group, cached, stemFinal);
            return;
        }
        AnswerResolver.resolveAsync(q, new AnswerResolver.Callback() {
            @Override
            public void onAnswer(Question qq, String answer, String from) {
                applyAnswer(act, qq, group, answer, stemFinal);
            }
        });
    }

    private static void applyAnswer(final Activity act, Question q, List<View> group,
                                    String answer, String stem) {
        if (answer == null || answer.length() == 0) return;
        if (VersionGate.dryRun()) {
            CxLog.i("【提示模式】" + answer + " -> " + AnswerResolver.shortStem(stem)
                    + "（当前学习通版本未适配，未点选）");
            return;
        }
        List<Integer> idx = AnswerResolver.mapToOptions(q, answer);
        if (idx.isEmpty()) {
            CxLog.w("原生页答案无法对应选项: " + answer + " | " + AnswerResolver.shortStem(stem));
            return;
        }
        for (final int i : idx) {
            if (i < 0 || i >= group.size()) continue;
            final View target = group.get(i);
            MAIN.postDelayed(new Runnable() {
                @Override
                public void run() {
                    try {
                        target.performClick();
                    } catch (Throwable t) {
                        CxLog.e("performClick 失败", t);
                    }
                }
            }, 320L + (long) (Math.random() * 1000) + i * 180L);
        }
        CxLog.i("原生页已作答 " + answer + " -> " + AnswerResolver.shortStem(stem));

        if (Cfg.b(K_SCROLL, false)) {
            MAIN.postDelayed(new Runnable() {
                @Override
                public void run() {
                    clickNext(act);
                }
            }, 900L);
        }
    }

    private static final String K_SCROLL = "auto_next";

    private static void clickNext(Activity act) {
        try {
            List<View> views = new ArrayList<>();
            collect(act.getWindow().getDecorView(), views, 0);
            for (View v : views) {
                if (!v.isClickable()) continue;
                String t = textOf(v);
                if (t.contains("下一题") || t.equals("下一頁") || t.contains("下一页")) {
                    v.performClick();
                    CxLog.i("已点击下一题");
                    return;
                }
            }
        } catch (Throwable ignored) {
        }
    }

    private static String findStem(List<View> views, List<View> options) {
        String bestKeyword = null;
        String longest = null;
        for (View v : views) {
            if (!(v instanceof TextView)) continue;
            if (options.contains(v)) continue;
            if (isAncestorOfAny(v, options)) continue;
            String t = textOf(v);
            if (t.length() < 4 || t.length() > 1200) continue;
            if (t.matches("^[A-H][.、．)）]?$")) continue;
            String id = idName(v);
            boolean hit = false;
            for (String k : Const.STEM_ID_KEYS) {
                if (id.toLowerCase().contains(k.toLowerCase())) {
                    hit = true;
                    break;
                }
            }
            if (hit && (bestKeyword == null || t.length() > bestKeyword.length())) bestKeyword = t;
            if (longest == null || t.length() > longest.length()) longest = t;
        }
        return bestKeyword != null ? bestKeyword : longest;
    }

    private static boolean isAncestorOfAny(View candidate, List<View> list) {
        for (View v : list) {
            ViewParent p = v.getParent();
            int guard = 0;
            while (p != null && guard++ < 20) {
                if (p == candidate) return true;
                p = p.getParent();
            }
        }
        return false;
    }

    private static String guessType(List<View> group) {
        for (View v : group) {
            if (v instanceof CheckBox) return "multi";
            if (v instanceof RadioButton) return "single";
            List<View> kids = new ArrayList<>();
            collect(v, kids, 0);
            for (View k : kids) {
                if (k instanceof CheckBox) return "multi";
                if (k instanceof RadioButton) return "single";
            }
        }
        if (group.size() == 2) {
            String a = Fuzzy.norm(textOf(group.get(0)));
            String b = Fuzzy.norm(textOf(group.get(1)));
            if ((a.equals("对") || a.equals("正确")) && (b.equals("错") || b.equals("错误"))) return "judge";
        }
        return "single";
    }

    private static boolean looksLikeOption(View v) {
        if (!(v instanceof TextView)) {
            if (v instanceof ViewGroup && v.isClickable()) {
                String t = textOf(v);
                return t.length() >= 1 && t.length() <= 200;
            }
            return false;
        }
        String t = textOf(v);
        if (t.length() == 0 || t.length() > 200) return false;
        if (v.isClickable()) return true;
        if (v instanceof CompoundButton) return true;
        String cls = v.getClass().getSimpleName();
        if (cls.contains("Radio") || cls.contains("Check") || cls.contains("Option")) return true;
        String id = idName(v).toLowerCase();
        if (id.length() > 0) {
            for (String k : Const.OPTION_KEYS) {
                if (id.contains(k)) return true;
            }
        }
        return false;
    }

    private static void collect(View v, List<View> out, int depth) {
        if (v == null || depth > 40) return;
        out.add(v);
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) {
                collect(g.getChildAt(i), out, depth + 1);
            }
        }
    }

    private static String textOf(View v) {
        if (v == null) return "";
        if (v instanceof TextView) {
            CharSequence cs = ((TextView) v).getText();
            return cs == null ? "" : cs.toString().replace('\u00a0', ' ').trim();
        }
        if (v instanceof ViewGroup) {
            StringBuilder sb = new StringBuilder();
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) {
                View c = g.getChildAt(i);
                if (c instanceof TextView) {
                    String t = textOf(c);
                    if (t.length() > 0) sb.append(t).append(' ');
                }
            }
            return sb.toString().trim();
        }
        return "";
    }

    private static String idName(View v) {
        try {
            int id = v.getId();
            if (id == View.NO_ID) return "";
            return v.getResources().getResourceEntryName(id);
        } catch (Throwable t) {
            return "";
        }
    }
}

package com.yinshibai.chaoxingx.free.ui;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.yinshibai.chaoxingx.free.BankStore;
import com.yinshibai.chaoxingx.free.Const;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

/** 题库管理：导入 / 导出 / 清空 / 浏览 */
public class BankActivity extends Activity {

    private static final int REQ_IMPORT = 1001;
    private static final int REQ_EXPORT = 1002;

    private LinearLayout list;
    private TextView info;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(14);
        root.setPadding(pad, pad, pad, pad);

        info = new TextView(this);
        info.setTextSize(14);
        info.setTextColor(Color.parseColor("#444444"));
        root.addView(info);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        Button imp = btn("导入");
        Button exp = btn("导出");
        Button clear = btn("清空");
        Button refresh = btn("刷新");
        row.addView(imp, weight());
        row.addView(exp, weight());
        row.addView(clear, weight());
        row.addView(refresh, weight());
        root.addView(row);

        ScrollView scroll = new ScrollView(this);
        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(list, new ViewGroup.LayoutParams(-1, -2));
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));
        setContentView(root);

        imp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                startActivityForResult(i, REQ_IMPORT);
            }
        });
        exp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("application/json");
                i.putExtra(Intent.EXTRA_TITLE, "cxai_bank.json");
                startActivityForResult(i, REQ_EXPORT);
            }
        });
        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int n = BankStore.clear();
                load();
                toast("已清空 " + n + " 条");
            }
        });
        refresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                load();
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        load();
    }

    private void load() {
        list.removeAllViews();
        int n = BankStore.count();
        info.setText("共 " + n + " 条（模糊阈值 " + (int) (Const.BANK_SIM * 100) + "%）");
        Cursor c = null;
        try {
            c = getContentResolver().query(Uri.parse("content://" + Const.AUTHORITY + "/list"),
                    null, null, new String[]{"0", "300"}, null);
            if (c == null) return;
            while (c.moveToNext()) {
                String stem = c.getString(0);
                String ans = c.getString(1);
                TextView tv = new TextView(this);
                tv.setTextSize(13);
                tv.setTextColor(Color.parseColor("#333333"));
                tv.setText("• " + stem + "\n   → " + ans);
                tv.setPadding(0, dp(6), 0, dp(6));
                list.addView(tv);
            }
        } catch (Throwable t) {
            info.setText("读取失败: " + t);
        } finally {
            if (c != null) c.close();
        }
        if (list.getChildCount() == 0) {
            TextView tv = new TextView(this);
            tv.setText("题库为空。答题过程中会自动累积。");
            tv.setTextColor(Color.parseColor("#999999"));
            list.addView(tv);
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        if (req == REQ_IMPORT) doImport(uri);
        if (req == REQ_EXPORT) doExport(uri);
    }

    private void doImport(Uri uri) {
        try {
            InputStream in = getContentResolver().openInputStream(uri);
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
            in.close();
            String text = bos.toString("UTF-8");
            int added = 0;
            JSONArray items;
            if (text.trim().startsWith("[")) {
                items = new JSONArray(text);
            } else {
                items = new JSONObject(text).optJSONArray("items");
            }
            if (items == null) {
                toast("文件格式不对，需要 {\"items\":[...]}");
                return;
            }
            for (int i = 0; i < items.length(); i++) {
                JSONObject o = items.optJSONObject(i);
                if (o == null) continue;
                String q = o.optString("q", o.optString("question", ""));
                String a = o.optString("a", o.optString("answer", ""));
                String t = o.optString("t", o.optString("type", "unknown"));
                if (q.length() < 4) continue;
                ContentValues v = new ContentValues();
                v.put("stem", q);
                v.put("answer", a);
                v.put("type", t);
                getContentResolver().insert(Uri.parse("content://" + Const.AUTHORITY + "/entry"), v);
                added++;
            }
            load();
            toast("导入 " + added + " 条");
        } catch (Throwable t) {
            toast("导入失败: " + t.getMessage());
        }
    }

    private void doExport(Uri uri) {
        try {
            String json = BankStore.exportJson();
            OutputStream out = getContentResolver().openOutputStream(uri);
            out.write(json.getBytes(StandardCharsets.UTF_8));
            out.flush();
            out.close();
            toast("已导出");
        } catch (Throwable t) {
            toast("导出失败: " + t.getMessage());
        }
    }

    private Button btn(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextSize(13);
        return b;
    }

    private LinearLayout.LayoutParams weight() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
        lp.setMargins(dp(3), 0, dp(3), 0);
        return lp;
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }
}

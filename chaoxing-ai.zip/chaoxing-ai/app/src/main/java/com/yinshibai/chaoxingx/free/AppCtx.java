package com.yinshibai.chaoxingx.free;

import android.app.Application;
import android.content.Context;

import java.lang.reflect.Method;

/** 全局 Context 兜底获取（AppGlobals 是 @hide，必须反射，不能直接编译引用） */
public final class AppCtx {
    private AppCtx() {}

    private static volatile Context cached;

    public static void set(Context c) {
        if (c != null) cached = c;
    }

    public static Context get() {
        Context c = cached;
        if (c != null) return c;
        try {
            Class<?> clazz = Class.forName("android.app.AppGlobals");
            Method m = clazz.getMethod("getInitialApplication");
            Object app = m.invoke(null);
            if (app instanceof Application) {
                cached = (Application) app;
                return cached;
            }
        } catch (Throwable ignored) {
        }
        try {
            Class<?> at = Class.forName("android.app.ActivityThread");
            Method cur = at.getMethod("currentApplication");
            Object app = cur.invoke(null);
            if (app instanceof Application) {
                cached = (Application) app;
                return cached;
            }
        } catch (Throwable ignored) {
        }
        return null;
    }
}

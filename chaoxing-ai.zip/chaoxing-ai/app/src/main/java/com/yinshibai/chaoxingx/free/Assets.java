package com.yinshibai.chaoxingx.free;

import android.content.Context;
import android.content.pm.PackageManager;
import android.content.res.AssetManager;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;

/** 读取模块 APK 自身 assets（Hook 运行时进程属于学习通，需要跨包拿资源） */
public final class Assets {
    private Assets() {}

    private static volatile String injectCache;

    /** 桥名占位符会被替换成运行期随机名 */
    public static String injectJs(Context app, String bridgeName) {
        String c = injectCache;
        if (c == null) {
            String js = read(app, "inject.js");
            if (js == null) js = FALLBACK_JS;
            c = js;
            injectCache = c;
        }
        return c.replace("__BRIDGE_NAME__", bridgeName);
    }

    public static String read(Context app, String name) {
        InputStream in = null;
        try {
            AssetManager am = null;
            if (app != null) {
                try {
                    Context moduleCtx = app.createPackageContext(Const.MODULE_PKG,
                            Context.CONTEXT_IGNORE_SECURITY | Context.CONTEXT_INCLUDE_CODE);
                    am = moduleCtx.getAssets();
                } catch (Throwable ignored) {
                    am = null;
                }
            }
            if (am == null) {
                try {
                    Context fallback = AppCtx.get();
                    if (fallback == null) return null;
                    Context moduleCtx = fallback.createPackageContext(Const.MODULE_PKG,
                            Context.CONTEXT_IGNORE_SECURITY);
                    am = moduleCtx.getAssets();
                } catch (Throwable t) {
                    return null;
                }
            }
            in = am.open(name);
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
            return bos.toString("UTF-8");
        } catch (Throwable t) {
            CxLog.e("assets 读取失败: " + name, t);
            return null;
        } finally {
            try {
                if (in != null) in.close();
            } catch (Throwable ignored) {
            }
        }
    }

    /** assets 不可用时的极简兜底脚本：仅处理答案格式为字母的单选题 */
    private static final String FALLBACK_JS =
            "(function(){if(window.__cxaiInstalled)return;window.__cxaiInstalled=true;" +
            "function n(s){return String(s||'').replace(/\\s+/g,'');}" +
            "function scan(){var bs=document.querySelectorAll('[class*=question],[class*=TiMu],.TiMu');" +
            "for(var i=0;i<bs.length;i++){var b=bs[i];if(b.__d)continue;" +
            "var ins=b.querySelectorAll('input[type=radio],input[type=checkbox]');if(!ins.length)continue;" +
            "var ts=[];for(var j=0;j<ins.length;j++){var h=ins[j].closest('label,li,div')||ins[j].parentNode;" +
            "ts.push((h.innerText||'').trim());}" +
            "var stem=(b.innerText||'').trim();var a='';try{a=window['__BRIDGE_NAME__'].answer(stem,JSON.stringify(ts),'single');}catch(e){return;}" +
            "if(!a)continue;b.__cxaiDone=true;" +
            "for(var k=0;k<a.length;k++){var idx=a.charCodeAt(k)-65;if(idx>=0&&idx<ins.length){ins[idx].click();}}}}" +
            "setTimeout(scan,1500);setInterval(scan,2000);})();";
}

package com.yinshibai.chaoxingx.free;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.ArrayDeque;
import java.util.List;

/**
 * 题库 / 日志 / 配置总线。
 * 学习通进程（Hook 侧）无法读写模块私有目录，因此统一走本 Provider：
 *  - find     : 按题干模糊查答案
 *  - count    : 题库条数
 *  - export   : 导出全量 JSON 字符串
 *  - list     : 分页列出条目
 *  - logs     : 读取运行日志
 *  - insert   : entry（入库一条）/ log（写一行日志）
 *  - delete   : entry?stem=.. / all / logs
 */
public class BankProvider extends ContentProvider {

    public static final String AUTH = Const.AUTHORITY;

    private static final int FIND = 1, COUNT = 2, EXPORT = 3, LIST = 4, LOGS = 5, ENTRY = 6, LOG = 7;
    private static final UriMatcher MATCHER = new UriMatcher(UriMatcher.NO_MATCH);

    static {
        MATCHER.addURI(AUTH, "find", FIND);
        MATCHER.addURI(AUTH, "count", COUNT);
        MATCHER.addURI(AUTH, "export", EXPORT);
        MATCHER.addURI(AUTH, "list", LIST);
        MATCHER.addURI(AUTH, "logs", LOGS);
        MATCHER.addURI(AUTH, "entry", ENTRY);
        MATCHER.addURI(AUTH, "log", LOG);
    }

    private static final Object LOCK = new Object();
    private static final ArrayDeque<String> LOG_RING = new ArrayDeque<>();
    private static final int LOG_MAX = 500;
    private static boolean loaded = false;

    /** 只允许本模块与学习通访问：Provider 是 exported 的，必须自己卡调用方 UID */
    private static final String[] ALLOWED_PKGS = {Const.MODULE_PKG, Const.TARGET};
    private static final int MAX_ENTRIES = 20000;
    private static final int MAX_STEM = 2000;
    private static final int MAX_ANSWER = 500;

    private boolean callerAllowed() {
        try {
            int uid = android.os.Binder.getCallingUid();
            if (uid == android.os.Process.myUid() || uid == 0) return true;
            Context c = ctx != null ? ctx : getContext();
            if (c == null) return false;
            String[] pkgs = c.getPackageManager().getPackagesForUid(uid);
            if (pkgs == null) return false;
            for (String p : pkgs) {
                for (String a : ALLOWED_PKGS) {
                    if (a.equals(p)) return true;
                }
            }
            CxLog.w("拒绝 Provider 访问, uid=" + uid);
        } catch (Throwable ignored) {
        }
        return false;
    }

    private static File bankFile() {
        java.io.File dir = null;
        try {
            if (ctx != null) dir = ctx.getFilesDir();
        } catch (Throwable ignored) {
        }
        if (dir == null) {
            dir = new File("/data/data/" + Const.MODULE_PKG + "/files");
        }
        return new File(dir, "bank.json");
    }

    private static Context ctx;

    @Override
    public boolean onCreate() {
        try {
            ctx = getContext();
            AppCtx.set(ctx);
        } catch (Throwable ignored) {
        }
        ensureLoaded();
        return true;
    }

    private static File logFile() {
        return new File(bankFile().getParentFile(), "logs.txt");
    }

    // ------------------------------------------------------------------ 存储

    private static void ensureLoaded() {
        if (loaded) return;
        synchronized (LOCK) {
            if (loaded) return;
            try {
                File f = bankFile();
                if (f.exists()) {
                    InputStream in = new FileInputStream(f);
                    ByteArrayOutputStream bos = new ByteArrayOutputStream();
                    byte[] buf = new byte[8192];
                    int n;
                    while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
                    in.close();
                    bankCache = parse(bos.toString("UTF-8"));
                }
            } catch (Throwable t) {
                CxLog.e("bank load failed", t);
            }
            try {
                File lf = logFile();
                if (lf.exists()) {
                    InputStream in = new FileInputStream(lf);
                    ByteArrayOutputStream bos = new ByteArrayOutputStream();
                    byte[] buf = new byte[8192];
                    int n;
                    while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
                    in.close();
                    for (String line : bos.toString("UTF-8").split("\n")) {
                        if (line.trim().length() == 0) continue;
                        LOG_RING.addLast(line);
                        while (LOG_RING.size() > LOG_MAX) LOG_RING.removeFirst();
                    }
                }
            } catch (Throwable ignored) {
            }
            loaded = true;
        }
    }

    private static List<Question> bankCache = new ArrayList<>();

    private static List<Question> parse(String json) {
        List<Question> out = new ArrayList<>();
        try {
            JSONObject root = new JSONObject(json);
            JSONArray items = root.optJSONArray("items");
            if (items == null) return out;
            for (int i = 0; i < items.length(); i++) {
                JSONObject o = items.optJSONObject(i);
                if (o == null) continue;
                Question q = new Question();
                q.stem = o.optString("q", "");
                q.answer = o.optString("a", "");
                q.type = o.optString("t", "unknown");
                if (q.stem.length() > 0) out.add(q);
            }
        } catch (Throwable t) {
            CxLog.e("bank parse failed", t);
        }
        return out;
    }

    private static String dumpJson() {
        JSONObject root = new JSONObject();
        try {
            root.put("v", 1);
            JSONArray arr = new JSONArray();
            for (Question q : bankCache) {
                JSONObject o = new JSONObject();
                o.put("q", q.stem);
                o.put("a", q.answer);
                o.put("t", q.type);
                arr.put(o);
            }
            root.put("items", arr);
        } catch (Throwable ignored) {
        }
        return root.toString();
    }

    private static void persist() {
        try {
            File f = bankFile();
            File dir = f.getParentFile();
            if (dir != null && !dir.exists()) dir.mkdirs();
            FileOutputStream out = new FileOutputStream(f);
            out.write(dumpJson().getBytes("UTF-8"));
            out.flush();
            out.close();
        } catch (Throwable t) {
            CxLog.e("bank persist failed", t);
        }
    }

    private static void persistLogs() {
        try {
            File f = logFile();
            FileOutputStream out = new FileOutputStream(f);
            StringBuilder sb = new StringBuilder();
            for (String s : LOG_RING) sb.append(s).append('\n');
            out.write(sb.toString().getBytes("UTF-8"));
            out.flush();
            out.close();
        } catch (Throwable ignored) {
        }
    }

    public static List<Question> snapshot() {
        ensureLoaded();
        synchronized (LOCK) {
            return new ArrayList<>(bankCache);
        }
    }

    // ------------------------------------------------------------- Provider

    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder) {
        if (!callerAllowed()) return null;
        ensureLoaded();
        int code;
        try {
            code = MATCHER.match(uri);
        } catch (Throwable t) {
            return null;
        }
        switch (code) {
            case FIND: {
                String stem = selectionArgs != null && selectionArgs.length > 0 ? selectionArgs[0] : selection;
                MatrixCursor c = new MatrixCursor(new String[]{"answer", "stem", "score", "type"});
                if (stem == null || stem.length() == 0) return c;
                Question best = null;
                double bestScore = 0d;
                synchronized (LOCK) {
                    for (Question q : bankCache) {
                        double s = Fuzzy.sim(q.stem, stem);
                        if (s > bestScore) {
                            bestScore = s;
                            best = q;
                        }
                    }
                }
                if (best != null && bestScore >= Const.BANK_SIM) {
                    c.addRow(new Object[]{best.answer, best.stem, (int) (bestScore * 100), best.type});
                }
                return c;
            }
            case COUNT: {
                MatrixCursor c = new MatrixCursor(new String[]{"n"});
                synchronized (LOCK) {
                    c.addRow(new Object[]{bankCache.size()});
                }
                return c;
            }
            case EXPORT: {
                MatrixCursor c = new MatrixCursor(new String[]{"json"});
                synchronized (LOCK) {
                    c.addRow(new Object[]{dumpJson()});
                }
                return c;
            }
            case LIST: {
                int offset = 0, limit = 200;
                if (selectionArgs != null && selectionArgs.length >= 2) {
                    try {
                        offset = Integer.parseInt(selectionArgs[0]);
                        limit = Integer.parseInt(selectionArgs[1]);
                    } catch (Throwable ignored) {
                    }
                }
                MatrixCursor c = new MatrixCursor(new String[]{"stem", "answer", "type", "pos"});
                synchronized (LOCK) {
                    for (int i = offset; i < bankCache.size() && i < offset + limit; i++) {
                        Question q = bankCache.get(i);
                        c.addRow(new Object[]{q.stem, q.answer, q.type, i});
                    }
                }
                return c;
            }
            case LOGS: {
                MatrixCursor c = new MatrixCursor(new String[]{"line"});
                synchronized (LOG_RING) {
                    for (String line : LOG_RING) c.addRow(new Object[]{line});
                }
                return c;
            }
            default:
                return null;
        }
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {
        if (!callerAllowed()) return null;
        ensureLoaded();
        int code = MATCHER.match(uri);
        if (code == LOG) {
            String line = values == null ? "" : values.getAsString("line");
            if (line != null && line.length() > 0) {
                synchronized (LOG_RING) {
                    LOG_RING.addLast(line);
                    while (LOG_RING.size() > LOG_MAX) LOG_RING.removeFirst();
                }
                if (LOG_RING.size() % 20 == 0) persistLogs();
            }
            return uri;
        }
        if (code == ENTRY) {
            String stem = values == null ? null : values.getAsString("stem");
            String ans = values == null ? "" : values.getAsString("answer");
            String type = values == null ? "unknown" : values.getAsString("type");
            if (stem == null || stem.length() < 4) return null;
            if (stem.length() > MAX_STEM) stem = stem.substring(0, MAX_STEM);
            if (ans != null && ans.length() > MAX_ANSWER) ans = ans.substring(0, MAX_ANSWER);
            synchronized (LOCK) {
                for (Question q : bankCache) {
                    if (Fuzzy.sim(q.stem, stem) >= 0.98) {
                        q.answer = ans == null ? "" : ans;
                        persist();
                        return uri;
                    }
                }
                Question q = new Question();
                q.stem = stem;
                q.answer = ans == null ? "" : ans;
                q.type = type == null ? "unknown" : type;
                bankCache.add(q);
                if (bankCache.size() > MAX_ENTRIES) bankCache.remove(0);
                persist();
            }
            return uri;
        }
        return null;
    }

    @Override
    public int bulkInsert(Uri uri, ContentValues[] values) {
        if (values == null) return 0;
        int n = 0;
        for (ContentValues v : values) {
            if (insert(uri, v) != null) n++;
        }
        return n;
    }

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        if (!callerAllowed()) return 0;
        ensureLoaded();
        synchronized (LOCK) {
            if ("all".equals(selection)) {
                int n = bankCache.size();
                bankCache.clear();
                persist();
                return n;
            }
            if ("logs".equals(selection)) {
                synchronized (LOG_RING) {
                    int n = LOG_RING.size();
                    LOG_RING.clear();
                    persistLogs();
                    return n;
                }
            }
            String stem = selectionArgs != null && selectionArgs.length > 0 ? selectionArgs[0] : selection;
            if (stem != null) {
                for (int i = bankCache.size() - 1; i >= 0; i--) {
                    if (Fuzzy.sim(bankCache.get(i).stem, stem) >= 0.98) {
                        bankCache.remove(i);
                        persist();
                        return 1;
                    }
                }
            }
        }
        return 0;
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
        return 0;
    }

    @Override
    public String getType(Uri uri) {
        return "vnd.android.cursor.dir/vnd.cxai.item";
    }
}

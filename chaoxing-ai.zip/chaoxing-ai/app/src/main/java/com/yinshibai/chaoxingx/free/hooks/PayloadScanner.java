package com.yinshibai.chaoxingx.free.hooks;

import com.yinshibai.chaoxingx.free.Fuzzy;
import com.yinshibai.chaoxingx.free.Question;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

/**
 * 从任意 JSON 响应里泛化提取题目。
 * 不用固定 schema —— 学习通各版本字段名差异很大，这里用字段名白名单递归扫描。
 */
public final class PayloadScanner {
    private PayloadScanner() {}

    private static final String[] STEM_KEYS = {
            "questionName", "questionContent", "questionTitle", "qContent", "stem",
            "topic", "subject", "title", "content", "question", "name", "body", "text"
    };
    private static final String[] OPTION_ARRAY_KEYS = {
            "options", "optionList", "optionItems", "answers", "answerList",
            "choices", "choiceList", "itemList", "items", "subQuestions"
    };
    private static final String[] OPTION_TEXT_KEYS = {
            "content", "name", "text", "value", "title", "optionContent", "optionName", "desc"
    };
    private static final String[] OPTION_KEY_KEYS = {
            "key", "optionKey", "no", "code", "index", "sort", "sortOrder", "letter"
    };
    private static final String[] TYPE_KEYS = {
            "questionType", "qType", "type", "questionMode", "category", "questionTypeId"
    };

    public static List<Question> scan(String body) {
        List<Question> out = new ArrayList<>();
        if (body == null) return out;
        String t = body.trim();
        if (t.length() < 20) return out;
        Object root;
        try {
            if (t.startsWith("[")) root = new JSONArray(t);
            else if (t.startsWith("{")) root = new JSONObject(t);
            else return out;
        } catch (Throwable ignored) {
            return out;
        }
        Set<String> seen = new HashSet<>();
        walk(root, out, seen, 0);
        return out;
    }

    private static void walk(Object node, List<Question> out, Set<String> seen, int depth) {
        if (node == null || depth > 14) return;
        if (node instanceof JSONArray) {
            JSONArray arr = (JSONArray) node;
            for (int i = 0; i < arr.length(); i++) walk(arr.opt(i), out, seen, depth + 1);
            return;
        }
        if (!(node instanceof JSONObject)) return;
        JSONObject obj = (JSONObject) node;

        Question q = tryAsQuestion(obj);
        if (q != null) {
            String key = Fuzzy.norm(q.stem);
            if (key.length() >= 4 && seen.add(key)) out.add(q);
        }

        Iterator<String> it = obj.keys();
        while (it.hasNext()) {
            String k = it.next();
            Object v = obj.opt(k);
            if (v instanceof JSONObject || v instanceof JSONArray) walk(v, out, seen, depth + 1);
        }
    }

    private static Question tryAsQuestion(JSONObject obj) {
        String stem = pickString(obj, STEM_KEYS, 8);
        if (stem == null) return null;

        Question q = new Question();
        q.stem = stem;
        q.source = "net";

        JSONArray optArr = pickArray(obj, OPTION_ARRAY_KEYS);
        if (optArr != null) {
            for (int i = 0; i < optArr.length(); i++) {
                Object o = optArr.opt(i);
                String text = null;
                String key = null;
                if (o instanceof JSONObject) {
                    JSONObject jo = (JSONObject) o;
                    text = pickString(jo, OPTION_TEXT_KEYS, 0);
                    key = pickString(jo, OPTION_KEY_KEYS, 0);
                } else if (o instanceof String) {
                    text = (String) o;
                }
                if (text == null) continue;
                text = text.trim();
                if (text.length() == 0 || text.length() > 400) continue;
                q.options.add(text);
                q.keys.add(key != null && key.trim().length() <= 2
                        ? key.trim().toUpperCase() : String.valueOf((char) ('A' + i)));
            }
        }

        String typeRaw = pickString(obj, TYPE_KEYS, 0);
        q.type = normalizeType(typeRaw, q.options);

        if (q.options.isEmpty() && "single".equals(q.type)) return null;
        if (q.options.isEmpty() && "multi".equals(q.type)) return null;
        if (q.stem.length() < 4) return null;
        return q;
    }

    private static String normalizeType(String raw, List<String> options) {
        if (raw != null) {
            String r = raw.trim().toLowerCase();
            if (r.contains("multi") || r.equals("2") || r.contains("多选")) return "multi";
            if (r.contains("single") || r.equals("1") || r.contains("单选")) return "single";
            if (r.contains("judge") || r.contains("true") || r.equals("3") || r.contains("判断")) return "judge";
            if (r.contains("fill") || r.contains("blank") || r.equals("4") || r.contains("填空")) return "fill";
            if (r.contains("short") || r.contains("essay") || r.equals("5") || r.contains("简答")) return "fill";
        }
        if (options.size() == 2) {
            String a = options.get(0);
            String b = options.get(1);
            if (isTrueText(a) && isFalseText(b)) return "judge";
        }
        return options.size() > 1 ? "single" : "unknown";
    }

    private static boolean isTrueText(String s) {
        String n = Fuzzy.norm(s);
        return n.equals("对") || n.equals("正确") || n.equals("是") || n.equals("t") || n.equals("true") || n.equals("√");
    }

    private static boolean isFalseText(String s) {
        String n = Fuzzy.norm(s);
        return n.equals("错") || n.equals("错误") || n.equals("否") || n.equals("f") || n.equals("false") || n.equals("×");
    }

    private static String pickString(JSONObject obj, String[] keys, int minLen) {
        for (String k : keys) {
            if (!obj.has(k)) continue;
            Object v = obj.opt(k);
            if (!(v instanceof String)) continue;
            String s = ((String) v).trim();
            if (s.length() < Math.max(minLen, 1)) continue;
            if (s.startsWith("{") || s.startsWith("[")) continue;
            if (s.length() > 4000) continue;
            return s;
        }
        return null;
    }

    private static JSONArray pickArray(JSONObject obj, String[] keys) {
        for (String k : keys) {
            JSONArray a = obj.optJSONArray(k);
            if (a != null && a.length() > 0) return a;
        }
        return null;
    }
}

package com.yinshibai.chaoxingx.free;

import android.app.Application;
import android.content.Context;

import com.yinshibai.chaoxingx.free.hooks.NativeHook;
import com.yinshibai.chaoxingx.free.hooks.NetHook;
import com.yinshibai.chaoxingx.free.hooks.StealthHook;
import com.yinshibai.chaoxingx.free.hooks.WebHook;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/** 模块入口（assets/xposed_init 指向本类） */
public class MainHook implements IXposedHookLoadPackage {

    private static volatile boolean started = false;

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) {
        if (lpparam == null || !Const.TARGET.equals(lpparam.packageName)) return;

        Cfg.init();
        CxLog.i("模块加载: " + lpparam.packageName + "/" + lpparam.processName);

        try {
            XposedHelpers.findAndHookMethod(Application.class, "attach", Context.class, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    try {
                        if (!(param.thisObject instanceof Application)) return;
                        Application app = (Application) param.thisObject;
                        boot(app, lpparam.classLoader);
                    } catch (Throwable t) {
                        CxLog.e("boot 失败", t);
                    }
                }
            });
        } catch (Throwable t) {
            CxLog.e("hook Application.attach 失败", t);
        }
    }

    private static synchronized void boot(Application app, ClassLoader cl) {
        if (started) return;
        started = true;
        try {
            BankStore.attach(app);
            AppCtx.set(app);
            VersionGate.check(app);
            CxLog.setProviderEnabled(Cfg.b(Cfg.K_LOG, true));
            CxLog.i("已就绪 · 题库 " + BankStore.count() + " 条 · 自动答题=" + Cfg.autoOn());
            NetHook.install(cl);
            WebHook.install(app, cl);
            NativeHook.install(cl);
            if (Cfg.b(Cfg.K_STEALTH, true)) StealthHook.install(cl);
        } catch (Throwable t) {
            CxLog.e("初始化异常", t);
        }
    }
}

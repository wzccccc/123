package com.yinshibai.chaoxingx.free.hooks;

import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

import com.yinshibai.chaoxingx.free.Const;
import com.yinshibai.chaoxingx.free.CxLog;

/**
 * 进程内反检测（被动隐藏）：
 *  1) 过滤调用栈里的 Xposed 帧（目标 App 常靠 Throwable().getStackTrace() 判断）
 *  2) 隐藏已知 Xposed/root 路径的存在性
 *  3) 从 PackageManager 结果里摘掉本模块包名
 *
 * 说明：/proc/self/maps 级别的隐藏（LSPosed dex、libxposed 段）在 Java 层做不可靠，
 * 需要 Shamiko / Zygisk 之类在 Zygote 层处理，见 docs/DETECTION.md。
 */
public final class StealthHook {
    private StealthHook() {}

    private static volatile boolean installed = false;

    private static final String[] BAD_WORDS = {
            "xposed", "lsposed", "edxposed", "epic", "sandhook", "riru", "zygisk",
            "shamiko", "magisk", "substrate", "cxai", "chaoxingx"
    };

    private static final String[] BAD_PATHS = {
            "/system/framework/XposedBridge.jar",
            "/system/lib/libxposed_art.so",
            "/system/lib64/libxposed_art.so",
            "/system/framework/edxp.jar",
            "/data/adb/modules/zygisk_lsposed",
            "/data/adb/modules/riru-core",
            "/data/adb/magisk",
            "/sbin/su", "/su/bin/su", "/system/bin/su", "/system/xbin/su",
            "/system/sbin/su", "/vendor/bin/su", "/magisk/.core/bin/su"
    };

    public static void install(ClassLoader cl) {
        if (installed) return;
        installed = true;
        hookStackTrace();
        hookFiles();
        hookPackageManager(cl);
        CxLog.i("反检测已启用（栈过滤 / 路径隐藏 / 包名隐藏）");
    }

    // ------------------------------------------------------------ 调用栈

    private static void hookStackTrace() {
        try {
            XposedBridge.hookAllMethods(Throwable.class, "getStackTrace", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    Object r = param.getResult();
                    if (!(r instanceof StackTraceElement[])) return;
                    StackTraceElement[] arr = (StackTraceElement[]) r;
                    List<StackTraceElement> keep = new ArrayList<>(arr.length);
                    boolean cut = false;
                    for (StackTraceElement e : arr) {
                        if (suspicious(e)) {
                            cut = true;
                            continue;
                        }
                        keep.add(e);
                    }
                    if (cut) param.setResult(keep.toArray(new StackTraceElement[0]));
                }
            });
        } catch (Throwable t) {
            CxLog.e("栈过滤安装失败", t);
        }
    }

    private static boolean suspicious(StackTraceElement e) {
        if (e == null) return false;
        String s = (e.getClassName() + "." + e.getMethodName() + "@" + e.getFileName()).toLowerCase();
        for (String b : BAD_WORDS) {
            if (s.contains(b)) return true;
        }
        return false;
    }

    // ------------------------------------------------------------ 文件存在性

    private static void hookFiles() {
        try {
            XposedHelpers.findAndHookMethod(File.class, "exists", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    File f = (File) param.thisObject;
                    if (f != null && isBadPath(f.getAbsolutePath())) param.setResult(Boolean.FALSE);
                }
            });
            XposedHelpers.findAndHookMethod(File.class, "canRead", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    File f = (File) param.thisObject;
                    if (f != null && isBadPath(f.getAbsolutePath())) param.setResult(Boolean.FALSE);
                }
            });
        } catch (Throwable t) {
            CxLog.e("路径隐藏安装失败", t);
        }
    }

    private static boolean isBadPath(String path) {
        if (path == null) return false;
        for (String p : BAD_PATHS) {
            if (path.equals(p)) return true;
        }
        return false;
    }

    // ------------------------------------------------------------ 包名

    private static void hookPackageManager(ClassLoader cl) {
        Class<?> apm = XposedHelpers.findClassIfExists("android.app.ApplicationPackageManager", cl);
        if (apm == null) return;
        try {
            XposedBridge.hookAllMethods(apm, "getInstalledPackages", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    Object r = param.getResult();
                    if (r instanceof List) param.setResult(filter((List<?>) r));
                }
            });
            XposedBridge.hookAllMethods(apm, "getInstalledApplications", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    Object r = param.getResult();
                    if (r instanceof List) param.setResult(filter((List<?>) r));
                }
            });
        } catch (Throwable t) {
            CxLog.e("包列表隐藏安装失败", t);
        }
        try {
            XposedHelpers.findAndHookMethod(apm, "getPackageInfo", String.class, int.class,
                    new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            if (param.args[0] instanceof String
                                    && Const.MODULE_PKG.equals(param.args[0])) {
                                param.setThrowable(new android.content.pm.PackageManager.NameNotFoundException(
                                        Const.MODULE_PKG));
                            }
                        }
                    });
        } catch (Throwable ignored) {
        }
    }

    private static List<Object> filter(List<?> in) {
        List<Object> out = new ArrayList<>(in.size());
        for (Object o : in) {
            String pkg = null;
            if (o instanceof PackageInfo) pkg = ((PackageInfo) o).packageName;
            else if (o instanceof ApplicationInfo) pkg = ((ApplicationInfo) o).packageName;
            if (pkg != null && Const.MODULE_PKG.equals(pkg)) continue;
            out.add(o);
        }
        return out;
    }
}

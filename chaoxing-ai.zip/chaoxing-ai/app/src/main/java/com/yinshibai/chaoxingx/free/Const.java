package com.yinshibai.chaoxingx.free;

/** 版本相关的常量集中在这里：换学习通版本只需要改本文件 */
public final class Const {
    private Const() {}

    /** 目标应用包名 */
    public static final String TARGET = "com.chaoxing.mobile";

    /** 与模块包名一致，用于跨进程读配置 */
    public static final String MODULE_PKG = "com.yinshibai.chaoxingx.free";

    /** ContentProvider authority（题库/日志总线） */
    public static final String AUTHORITY = MODULE_PKG + ".bank";

    /** 允许注入的 H5 域名特征（学习通答题页绝大多数在这些域下） */
    public static final String[] WEB_HOSTS = {
            "chaoxing.com", "edu.cn", "cldisk.com", "chaoxing.cn", "x.chaoxing.com"
    };

    /** 原生页里“题干”控件的 id 关键词 */
    public static final String[] STEM_ID_KEYS = {
            "question", "stem", "title", "timu", "topic", "subject", "tv_content", "tvContent"
    };

    /** 原生页里“选项”控件的 id 关键词 / 类名关键词 */
    public static final String[] OPTION_KEYS = {
            "option", "answer", "choice", "select", "radio", "check", "item"
    };

    /** 单个 AI 请求默认超时（毫秒） */
    public static final int AI_TIMEOUT_MS = 25000;

    /** 题库相似度命中阈值（0~1） */
    public static final double BANK_SIM = 0.88;

    /** 同一题干在内存里的重复拦截窗口（毫秒） */
    public static final long DEDUP_MS = 60_000L;
}

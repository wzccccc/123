package com.yinshibai.chaoxingx.free;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * 答案决策链：内存缓存 → 本地题库 → AI → 回写题库
 * 免卡密版没有任何授权校验，配置齐全即可直接用。
 */
public final class AnswerResolver {
    private AnswerResolver() {}

    public interface Callback {
        void onAnswer(Question q, String answer, String from);
    }

    private static final ExecutorService POOL = Executors.newFixedThreadPool(2);
    private static final int MEM_MAX = 300;
    private static final LinkedHashMap<String, String> MEM =
            new LinkedHashMap<String, String>() {
                @Override
                protected boolean removeEldestEntry(Map.Entry<String, String> eldest) {
                    return size() > MEM_MAX;
                }
            };
    private static final Map<String, Long> SEEN = new LinkedHashMap<>();
    private static final Object LOCK = new Object();

    /** 阻塞式求解（WebView JS 桥直接同步调用） */
    public static String resolve(Question q) {
        if (q == null || !q.valid()) return null;
        String key = Fuzzy.norm(q.stem);
        if (key.length() == 0) return null;

        synchronized (LOCK) {
            String mem = MEM.get(key);
            if (mem != null) {
                CxLog.i("命中内存缓存: " + shortStem(q.stem));
                return mem;
            }
        }

        // 1) 本地题库
        String bankAnswer = null;
        if (Cfg.cacheOn() || Cfg.bankFirst()) {
            String[] type = new String[1];
            bankAnswer = BankStore.find(q.stem, type);
            if (bankAnswer != null && bankAnswer.length() > 0 && "unknown".equals(q.type) && type[0] != null) {
                q.type = type[0];
            }
        }

        if (bankAnswer != null && bankAnswer.length() > 0 && Cfg.bankFirst() && !Cfg.hintMode()) {
            CxLog.i("题库命中: " + shortStem(q.stem) + " -> " + bankAnswer);
            cache(key, bankAnswer);
            return bankAnswer;
        }

        // 2) AI
        String answer;
        try {
            String raw = AiClient.chat(Prompt.system(Prompt.isZh()), Prompt.user(q, bankAnswer));
            answer = Prompt.extract(raw);
            CxLog.i("AI 作答: " + shortStem(q.stem) + " -> " + answer + " (raw=" + short(raw) + ")");
        } catch (Throwable t) {
            CxLog.e("AI 请求失败", t);
            if (bankAnswer != null && bankAnswer.length() > 0) {
                cache(key, bankAnswer);
                return bankAnswer;
            }
            return null;
        }

        if (answer == null || answer.length() == 0) {
            if (bankAnswer != null && bankAnswer.length() > 0) return bankAnswer;
            return null;
        }

        // 3) 回写题库
        if (Cfg.cacheOn()) BankStore.put(q.stem, answer, q.type);
        cache(key, answer);
        return answer;
    }

    public static void resolveAsync(final Question q, final Callback cb) {
        if (isDuplicate(q)) {
            String cached = peek(q == null ? null : q.stem);
            if (cached != null && cb != null) cb.onAnswer(q, cached, "cache");
            CxLog.i("重复题拦截: " + shortStem(q == null ? "" : q.stem));
            return;
        }
        POOL.execute(new Runnable() {
            @Override
            public void run() {
                String ans = null;
                try {
                    ans = resolve(q);
                } catch (Throwable t) {
                    CxLog.e("resolveAsync 异常", t);
                }
                if (cb != null && ans != null && ans.length() > 0) cb.onAnswer(q, ans, "auto");
            }
        });
    }

    /** 只查内存缓存，不触发网络（主线程安全） */
    public static String peek(String stem) {
        if (stem == null) return null;
        String key = Fuzzy.norm(stem);
        if (key.length() == 0) return null;
        synchronized (LOCK) {
            return MEM.get(key);
        }
    }

    private static boolean isDuplicate(Question q) {
        if (q == null) return true;
        String key = Fuzzy.norm(q.stem);
        long now = System.currentTimeMillis();
        synchronized (LOCK) {
            Long last = SEEN.get(key);
            if (last != null && now - last < Const.DEDUP_MS) return true;
            SEEN.put(key, now);
            if (SEEN.size() > 400) {
                List<String> dead = new ArrayList<>();
                for (Map.Entry<String, Long> e : SEEN.entrySet()) {
                    if (now - e.getValue() > Const.DEDUP_MS) dead.add(e.getKey());
                }
                for (String d : dead) SEEN.remove(d);
            }
        }
        return false;
    }

    private static void cache(String key, String answer) {
        synchronized (LOCK) {
            MEM.put(key, answer);
        }
    }

    /** 答案 → 选项下标集合（原生页点击用） */
    public static List<Integer> mapToOptions(Question q, String answer) {
        List<Integer> out = new ArrayList<>();
        if (q == null || answer == null) return out;
        String ans = Fuzzy.norm(answer).toUpperCase(Locale.US);
        if (ans.length() == 0) return out;

        boolean allLetters = ans.matches("^[A-H]+$");
        if (allLetters) {
            for (int i = 0; i < ans.length(); i++) {
                int idx = ans.charAt(i) - 'A';
                if (idx >= 0 && idx < q.options.size()) out.add(idx);
            }
            if (!out.isEmpty()) return out;
        }

        for (int i = 0; i < q.options.size(); i++) {
            String o = Fuzzy.norm(q.options.get(i));
            if (o.length() == 0) continue;
            if (o.equals(ans) || o.startsWith(ans) || ans.startsWith(o)) out.add(i);
        }
        if (!out.isEmpty()) return out;

        boolean t = ans.matches("^(对|正确|是|T|TRUE|YES|√)$");
        boolean f = ans.matches("^(错|错误|否|F|FALSE|NO|×|X)$");
        if (t || f) {
            for (int i = 0; i < q.options.size(); i++) {
                String o = Fuzzy.norm(q.options.get(i));
                if (t && o.matches("^(对|正确|是|√|t|true)$")) out.add(i);
                if (f && o.matches("^(错|错误|否|×|x|f|false)$")) out.add(i);
            }
        }
        return out;
    }

    public static String shortStem(String s) {
        if (s == null) return "";
        String t = s.replaceAll("\\s+", " ").trim();
        return t.length() <= 22 ? t : t.substring(0, 22) + "…";
    }

    private static String short(String s) {
        if (s == null) return "";
        String t = s.replaceAll("\\s+", " ");
        return t.length() <= 60 ? t : t.substring(0, 60) + "…";
    }
}

package com.yinshibai.chaoxingx.free.hooks;

import com.yinshibai.chaoxingx.free.AnswerResolver;
import com.yinshibai.chaoxingx.free.Cfg;
import com.yinshibai.chaoxingx.free.CxLog;
import com.yinshibai.chaoxingx.free.Question;

import java.lang.reflect.Method;
import java.util.List;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

/**
 * OkHttp 层拦截：把响应里的题目提前喂给 AI 求解并写入内存缓存/题库，
 * 等 UI 层真正填空时直接命中，做到“零等待”。
 */
public final class NetHook {
    private NetHook() {}

    private static volatile boolean installed = false;

    public static void install(ClassLoader cl) {
        if (installed) return;
        installed = true;
        boolean ok = false;
        ok |= hookChain(cl, "okhttp3.RealInterceptorChain");
        ok |= hookChain(cl, "okhttp3.internal.http.RealInterceptorChain");
        if (!ok) CxLog.w("未找到 OkHttp 拦截点（该版本可能不走 OkHttp 或已混淆）");
        else CxLog.i("OkHttp 拦截已安装");
    }

    private static boolean hookChain(ClassLoader cl, String className) {
        Class<?> clazz = XposedHelpers.findClassIfExists(className, cl);
        if (clazz == null) return false;
        try {
            XposedBridge.hookAllMethods(clazz, "proceed", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    try {
                        onResponse(param);
                    } catch (Throwable t) {
                        CxLog.e("NetHook 处理异常", t);
                    }
                }
            });
            CxLog.i("拦截 " + className + ".proceed");
            return true;
        } catch (Throwable t) {
            CxLog.e("hook " + className + " 失败", t);
            return false;
        }
    }

    private static void onResponse(XC_MethodHook.MethodHookParam param) {
        if (!Cfg.autoOn()) return;
        Object resp = param.getResult();
        if (resp == null) return;
        String url = urlOf(param.args);
        String body = peek(resp);
        if (body == null) return;
        String lower = body.length() > 400 ? body.substring(0, 400) : body;
        if (lower.indexOf("question") < 0 && lower.indexOf("options") < 0 && lower.indexOf("题目") < 0) return;

        List<Question> qs = PayloadScanner.scan(body);
        if (qs.isEmpty()) return;
        CxLog.i("网络捕获题目 " + qs.size() + " 道 @" + shortUrl(url));
        for (Question q : qs) {
            AnswerResolver.resolveAsync(q, null);
        }
    }

    private static String urlOf(Object[] args) {
        if (args == null) return "";
        for (Object a : args) {
            if (a == null) continue;
            try {
                if (a.getClass().getName().equals("okhttp3.Request")) {
                    Object url = a.getClass().getMethod("url").invoke(a);
                    return String.valueOf(url);
                }
            } catch (Throwable ignored) {
            }
        }
        return "";
    }

    private static String peek(Object resp) {
        try {
            Method m = resp.getClass().getMethod("peekBody", long.class);
            Object rb = m.invoke(resp, 2L * 1024 * 1024);
            return bodyString(rb);
        } catch (Throwable ignored) {
        }
        try {
            java.lang.reflect.Field f = resp.getClass().getDeclaredField("body");
            f.setAccessible(true);
            return bodyString(f.get(resp));
        } catch (Throwable ignored) {
        }
        return null;
    }

    private static String bodyString(Object rb) {
        if (rb == null) return null;
        try {
            Method s = rb.getClass().getMethod("string");
            Object v = s.invoke(rb);
            return v instanceof String ? (String) v : null;
        } catch (Throwable ignored) {
            return null;
        }
    }

    private static String shortUrl(String url) {
        if (url == null) return "";
        int q = url.indexOf('?');
        String s = q > 0 ? url.substring(0, q) : url;
        return s.length() <= 80 ? s : s.substring(0, 80) + "…";
    }
}

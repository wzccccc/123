package com.yinshibai.chaoxingx.free;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/** OpenAI 兼容 Chat Completions 客户端（DeepSeek / 通义 / 智谱 / Ollama / one-api 均可） */
public final class AiClient {
    private AiClient() {}

    public static String chat(String system, String user) throws Exception {
        String base = Cfg.s(Cfg.K_BASE, Cfg.DEF_BASE).trim();
        String key = Cfg.s(Cfg.K_KEY, "").trim();
        String model = Cfg.s(Cfg.K_MODEL, Cfg.DEF_MODEL).trim();
        float temp = Cfg.f(Cfg.K_TEMP, 0.1f);
        int timeout = Cfg.i(Cfg.K_TIMEOUT, 25) * 1000;

        if (base.length() == 0) throw new IOException("未配置 API Base URL");
        if (model.length() == 0) throw new IOException("未配置模型名");

        String url = endpoint(base);
        requireSecure(url);

        JSONObject body = new JSONObject();
        body.put("model", model);
        body.put("temperature", temp);
        body.put("max_tokens", 800);
        body.put("stream", false);
        JSONArray messages = new JSONArray();
        JSONObject sys = new JSONObject();
        sys.put("role", "system");
        sys.put("content", system);
        messages.put(sys);
        JSONObject usr = new JSONObject();
        usr.put("role", "user");
        usr.put("content", user);
        messages.put(usr);
        body.put("messages", messages);

        byte[] payload = body.toString().getBytes(StandardCharsets.UTF_8);

        HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
        conn.setRequestMethod("POST");
        conn.setConnectTimeout(Math.min(timeout, 15000));
        conn.setReadTimeout(timeout);
        conn.setDoOutput(true);
        conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
        conn.setRequestProperty("Accept", "application/json");
        if (key.length() > 0) conn.setRequestProperty("Authorization", "Bearer " + key);

        OutputStream os = conn.getOutputStream();
        os.write(payload);
        os.flush();
        os.close();

        int code = conn.getResponseCode();
        String resp;
        if (code >= 200 && code < 300) {
            resp = readAll(conn.getInputStream());
        } else {
            String err = readAll(conn.getErrorStream());
            throw new IOException("HTTP " + code + " " + trim(err, 300));
        }

        JSONObject root = new JSONObject(resp);
        JSONArray choices = root.optJSONArray("choices");
        if (choices == null || choices.length() == 0) throw new IOException("响应无 choices: " + trim(resp, 200));
        JSONObject c0 = choices.optJSONObject(0);
        JSONObject msg = c0 == null ? null : c0.optJSONObject("message");
        String content = msg == null ? "" : msg.optString("content", "");
        if (content.trim().length() == 0 && msg != null) {
            content = msg.optString("reasoning_content", "");
        }
        return content;
    }

    /** 连通性测试：给一句固定问题，返回耗时文本 */
    public static String ping() throws Exception {
        long t0 = System.currentTimeMillis();
        String out = chat("你是一个回声助手，原样回显用户内容。", "ping");
        long cost = System.currentTimeMillis() - t0;
        return "OK " + cost + "ms :: " + trim(out, 80);
    }

    /** 明文 http 仅放行本地模型；API Key 与题干不允许明文上线 */
    private static void requireSecure(String url) throws IOException {
        String lower = url.toLowerCase();
        if (lower.startsWith("https://")) return;
        if (!lower.startsWith("http://")) throw new IOException("Base URL 必须以 http(s):// 开头");
        String host;
        try {
            host = new URL(url).getHost();
        } catch (Throwable t) {
            host = "";
        }
        if (host == null) host = "";
        host = host.toLowerCase();
        if (host.equals("127.0.0.1") || host.equals("localhost") || host.equals("::1")
                || host.startsWith("10.") || host.startsWith("192.168.") || host.equals("10.0.2.2")) {
            return;
        }
        throw new IOException("拒绝明文 HTTP：" + host + " —— API Key 与题干会明文外泄，除本地模型外请用 https");
    }

    private static String endpoint(String base) {        String b = base;
        while (b.endsWith("/")) b = b.substring(0, b.length() - 1);
        if (b.endsWith("/chat/completions")) return b;
        if (b.contains("/chat/completions?")) return b;
        if (b.endsWith("/v1")) return b + "/chat/completions";
        return b + "/v1/chat/completions";
    }

    private static String readAll(InputStream in) throws IOException {
        if (in == null) return "";
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
        in.close();
        return new String(bos.toByteArray(), StandardCharsets.UTF_8);
    }

    private static String trim(String s, int max) {
        if (s == null) return "";
        s = s.replaceAll("\\s+", " ");
        return s.length() <= max ? s : s.substring(0, max) + "...";
    }
}

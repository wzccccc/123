package com.yinshibai.chaoxingx.free;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;

/** 客户端封装：Hook 侧与模块界面都通过它访问 BankProvider */
public final class BankStore {
    private BankStore() {}

    private static volatile Context ctx;

    /** Hook 侧启动时注入 Context（学习通进程的 Application） */
    public static void attach(Context context) {
        ctx = context;
    }

    private static Context c() {
        Context local = ctx;
        if (local != null) return local;
        local = AppCtx.get();
        if (local != null) ctx = local;
        return local;
    }

    private static Uri u(String path) {
        return Uri.parse("content://" + Const.AUTHORITY + "/" + path);
    }

    /** 题库精确/模糊查找，返回答案；未命中返回 null */
    public static String find(String stem, String[] outType) {
        Context context = c();
        if (context == null || stem == null) return null;
        Cursor cur = null;
        try {
            cur = context.getContentResolver().query(u("find"), null, stem, null, null);
            if (cur != null && cur.moveToFirst()) {
                String ans = cur.getString(cur.getColumnIndexOrThrow("answer"));
                if (outType != null && outType.length > 0) {
                    outType[0] = cur.getString(cur.getColumnIndexOrThrow("type"));
                }
                return ans;
            }
        } catch (Throwable t) {
            CxLog.e("bank find failed", t);
        } finally {
            if (cur != null) cur.close();
        }
        return null;
    }

    public static void put(String stem, String answer, String type) {
        Context context = c();
        if (context == null || stem == null) return;
        try {
            ContentValues v = new ContentValues();
            v.put("stem", stem);
            v.put("answer", answer == null ? "" : answer);
            v.put("type", type == null ? "unknown" : type);
            context.getContentResolver().insert(u("entry"), v);
        } catch (Throwable t) {
            CxLog.e("bank put failed", t);
        }
    }

    public static int count() {
        Context context = c();
        if (context == null) return 0;
        Cursor cur = null;
        try {
            cur = context.getContentResolver().query(u("count"), null, null, null, null);
            if (cur != null && cur.moveToFirst()) return cur.getInt(0);
        } catch (Throwable ignored) {
        } finally {
            if (cur != null) cur.close();
        }
        return 0;
    }

    public static String exportJson() {
        Context context = c();
        if (context == null) return "{}";
        Cursor cur = null;
        try {
            cur = context.getContentResolver().query(u("export"), null, null, null, null);
            if (cur != null && cur.moveToFirst()) return cur.getString(0);
        } catch (Throwable t) {
            CxLog.e("bank export failed", t);
        } finally {
            if (cur != null) cur.close();
        }
        return "{}";
    }

    public static int clear() {
        Context context = c();
        if (context == null) return 0;
        try {
            return context.getContentResolver().delete(u("entry"), "all", null);
        } catch (Throwable t) {
            CxLog.e("bank clear failed", t);
        }
        return 0;
    }

    private static final ThreadLocal<Boolean> IN_LOG = new ThreadLocal<>();

    public static void log(String line) {
        if (Boolean.TRUE.equals(IN_LOG.get())) return;
        Context context = c();
        if (context == null) return;
        IN_LOG.set(Boolean.TRUE);
        try {
            ContentValues v = new ContentValues();
            v.put("line", line);
            context.getContentResolver().insert(u("log"), v);
        } catch (Throwable ignored) {
        } finally {
            IN_LOG.set(Boolean.FALSE);
        }
    }

    public static Cursor logs() {
        Context context = c();
        if (context == null) return null;
        try {
            return context.getContentResolver().query(u("logs"), null, null, null, null);
        } catch (Throwable t) {
            return null;
        }
    }
}

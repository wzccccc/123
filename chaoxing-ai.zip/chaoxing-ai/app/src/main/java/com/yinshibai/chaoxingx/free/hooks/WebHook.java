package com.yinshibai.chaoxingx.free.hooks;

import android.app.Application;
import android.os.Handler;
import android.os.Looper;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.yinshibai.chaoxingx.free.AnswerResolver;
import com.yinshibai.chaoxingx.free.Assets;
import com.yinshibai.chaoxingx.free.BankStore;
import com.yinshibai.chaoxingx.free.Cfg;
import com.yinshibai.chaoxingx.free.Const;
import com.yinshibai.chaoxingx.free.CxLog;
import com.yinshibai.chaoxingx.free.Question;
import com.yinshibai.chaoxingx.free.VersionGate;

import org.json.JSONArray;

import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

/** H5 答题页：注入脚本 + JS 桥，DOM 内自动点选 */
public final class WebHook {
    private WebHook() {}

    private static volatile boolean installed = false;
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static final Map<WebView, String> INJECTED = new WeakHashMap<>();
    private static final Map<WebView, String> BRIDGE = new WeakHashMap<>();
    private static volatile Application app;

    public static void install(Application application, ClassLoader cl) {
        if (installed) return;
        installed = true;
        app = application;
        try {
            XposedHelpers.findAndHookMethod(WebView.class, "loadUrl", String.class, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    final WebView wv = (WebView) param.thisObject;
                    final String url = (String) param.args[0];
                    scheduleInject(wv, url);
                }
            });
        } catch (Throwable t) {
            CxLog.e("hook loadUrl 失败", t);
        }
        try {
            XposedHelpers.findAndHookMethod(WebView.class, "loadUrl", String.class, Map.class, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    scheduleInject((WebView) param.thisObject, (String) param.args[0]);
                }
            });
        } catch (Throwable ignored) {
        }
        try {
            XposedHelpers.findAndHookMethod(WebView.class, "loadDataWithBaseURL", String.class, String.class,
                    String.class, String.class, String.class, new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            scheduleInject((WebView) param.thisObject, (String) param.args[3]);
                        }
                    });
        } catch (Throwable ignored) {
        }
        // 页面加载完成：不同版本 WebViewClient 子类会调用 super，这里兜一层
        try {
            XposedBridge.hookAllMethods(WebViewClient.class, "onPageFinished", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    if (param.args != null && param.args.length >= 2 && param.args[0] instanceof WebView) {
                        inject((WebView) param.args[0], String.valueOf(param.args[1]));
                    }
                }
            });
        } catch (Throwable ignored) {
        }
        CxLog.i("WebView 注入已安装");
    }

    /**
     * 严格域名后缀匹配：绝不用 contains，避免 chaoxing.com.evil.tld 这种仿冒域拿到 JS 桥。
     * file:// / data:// 不放行——本地页面不该能调用 answer() 花你的 token。
     */
    private static boolean hostAllowed(String url) {
        if (url == null) return false;
        String host;
        try {
            host = new java.net.URL(url).getHost();
        } catch (Throwable t) {
            return false;
        }
        if (host == null || host.length() == 0) return false;
        host = host.toLowerCase();
        for (String h : Const.WEB_HOSTS) {
            String d = h.toLowerCase();
            if (host.equals(d) || host.endsWith("." + d)) return true;
        }
        return false;
    }

    private static void scheduleInject(final WebView wv, final String url) {
        if (wv == null) return;
        if (!hostAllowed(url)) return;
        // 页面在加载中，分阶段补注入，覆盖懒加载/SPA 跳转
        long[] delays = {900L, 2500L, 5000L, 9000L, 14000L};
        for (long d : delays) {
            MAIN.postDelayed(new Runnable() {
                @Override
                public void run() {
                    inject(wv, url);
                }
            }, d);
        }
    }

    private static void inject(WebView wv, String url) {
        if (wv == null || !Cfg.autoOn()) return;
        String key = String.valueOf(url);
        int count = 0;
        synchronized (INJECTED) {
            String rec = INJECTED.get(wv);
            if (rec != null && rec.startsWith(key + "|")) {
                try {
                    count = Integer.parseInt(rec.substring(key.length() + 1));
                } catch (Throwable ignored) {
                }
            }
            if (count >= 2) return;
            INJECTED.put(wv, key + "|" + (count + 1));
        }
        // 桥对象名每次进程随机生成：页面无法用 window.CxAiFree 这种固定名探测
        String bridgeName;
        synchronized (BRIDGE) {
            bridgeName = BRIDGE.get(wv);
            if (bridgeName == null) {
                bridgeName = "__cx" + java.util.UUID.randomUUID().toString()
                        .replace("-", "").substring(0, 10);
                BRIDGE.put(wv, bridgeName);
            }
        }
        try {
            wv.addJavascriptInterface(new Bridge(wv), bridgeName);
        } catch (Throwable t) {
            CxLog.e("addJavascriptInterface 失败", t);
        }
        try {
            String js = Assets.injectJs(app, bridgeName);
            wv.evaluateJavascript(js, null);
            CxLog.i("已注入答题脚本 @" + trim(url));
        } catch (Throwable t) {
            CxLog.e("evaluateJavascript 失败", t);
        }
    }

    private static String trim(String s) {
        if (s == null) return "";
        int q = s.indexOf('?');
        String t = q > 0 ? s.substring(0, q) : s;
        return t.length() <= 70 ? t : t.substring(0, 70) + "…";
    }

    /** JS 桥：answer() 同步返回答案字符串 */
    public static class Bridge {
        private final WebView wv;

        Bridge(WebView wv) {
            this.wv = wv;
        }

        @JavascriptInterface
        public String answer(String stem, String optionsJson, String type) {
            try {
                if (!Cfg.autoOn()) return "";
                Question q = new Question();
                q.stem = stem == null ? "" : stem;
                q.type = type == null ? "single" : type;
                q.source = "web";
                if (optionsJson != null && optionsJson.length() > 2) {
                    JSONArray arr = new JSONArray(optionsJson);
                    for (int i = 0; i < arr.length(); i++) {
                        String o = arr.optString(i, "");
                        if (o == null) continue;
                        o = o.trim();
                        if (o.length() == 0) continue;
                        q.options.add(o);
                        q.keys.add(String.valueOf((char) ('A' + i)));
                    }
                }
                if (!q.valid()) return "";
                String ans = AnswerResolver.resolve(q);
                if (ans == null) return "";
                if (VersionGate.dryRun()) {
                    CxLog.i("【提示模式-Web】" + ans + " -> " + AnswerResolver.shortStem(q.stem));
                    return ""; // 返回空串，注入脚本不会点选
                }
                List<Integer> idx = AnswerResolver.mapToOptions(q, ans);
                if (idx.isEmpty()) return ans;
                return ans;
            } catch (Throwable t) {
                CxLog.e("bridge.answer 异常", t);
                return "";
            }
        }

        @JavascriptInterface
        public void log(String msg) {
            CxLog.i(msg == null ? "" : msg);
        }

        @JavascriptInterface
        public int bankCount() {
            return BankStore.count();
        }
    }
}

package com.yinshibai.chaoxingx.free;

import java.util.Locale;

/** 提示词构造与答案抽取 */
public final class Prompt {
    private Prompt() {}

    public static String system(boolean zh) {
        if (zh) {
            return "你是一个严谨的答题引擎。用户会给出题干与选项，你只输出最终答案，不要解释、不要复述题目。\n"
                    + "输出格式严格为一行：ANSWER: X\n"
                    + "X 的规则：\n"
                    + "1) 单选题输出 1 个选项字母，如 ANSWER: B\n"
                    + "2) 多选题输出全部正确选项字母，字母连续排列，如 ANSWER: ACD\n"
                    + "3) 判断题输出 对 或 错，如 ANSWER: 对\n"
                    + "4) 填空题输出答案文本本身，多个空用 | 分隔\n"
                    + "5) 简答题输出不超过 60 字的要点\n"
                    + "无法确定时输出 ANSWER: UNKNOWN";
        }
        return "You are a strict exam answering engine. Answer with one line only: ANSWER: X\n"
                + "Rules: single choice -> one letter; multiple choice -> letters concatenated; "
                + "true/false -> TRUE or FALSE; fill-in -> the text; short answer -> <= 60 words.\n"
                + "If uncertain output ANSWER: UNKNOWN";
    }

    public static boolean isZh() {
        return !"en".equalsIgnoreCase(Cfg.s(Cfg.K_LANG, "zh"));
    }

    public static String user(Question q, String bankHint) {
        StringBuilder sb = new StringBuilder();
        sb.append("题型: ").append(typeName(q.type)).append('\n');
        if (bankHint != null && bankHint.length() > 0) {
            sb.append("本地题库参考答案(仅供参考，可能不准): ").append(bankHint).append('\n');
        }
        String extra = Cfg.s(Cfg.K_PROMPT, "");
        if (extra.length() > 0) sb.append(extra).append('\n');
        sb.append("题目:\n").append(q.promptBody());
        sb.append("请按格式输出 ANSWER: ...");
        return sb.toString();
    }

    private static String typeName(String t) {
        if ("multi".equals(t)) return "多选题";
        if ("judge".equals(t)) return "判断题";
        if ("fill".equals(t)) return "填空题";
        if ("single".equals(t)) return "单选题";
        return "未知题型";
    }

    /** 从模型输出中抽取纯答案 */
    public static String extract(String raw) {
        if (raw == null) return "";
        String text = raw.trim();
        if (text.length() == 0) return "";

        String marker = "ANSWER:";
        int idx = text.toUpperCase(Locale.US).lastIndexOf(marker);
        String ans;
        if (idx >= 0) {
            ans = text.substring(idx + marker.length());
            int nl = ans.indexOf('\n');
            if (nl >= 0) ans = ans.substring(0, nl);
        } else {
            ans = text;
        }
        ans = ans.trim();
        ans = ans.replaceAll("^[`'\"“”‘’\\s]+", "").replaceAll("[`'\"“”‘’\\s]+$", "");
        ans = ans.replaceAll("^[（(]?(答案|答|选择)[)）:：\\s]*", "");
        ans = ans.replaceAll("[。.!！,，;；]+$", "");
        ans = ans.trim();

        if (ans.length() == 0) return "";

        // 纯字母选项
        String letters = ans.toUpperCase(Locale.US).replaceAll("[^A-H]", "");
        if (letters.length() > 0 && ans.replaceAll("[A-Ha-h\\s,，、和与及]", "").length() <= 2) {
            return sortLetters(letters);
        }

        // 判断题
        if (ans.matches("^(对|正确|是|√|T|TRUE|YES)$")) return "对";
        if (ans.matches("^(错|错误|否|×|X|F|FALSE|NO)$")) return "错";

        if (ans.equalsIgnoreCase("UNKNOWN")) return "";

        // 其他：取第一行，限制长度
        int nl = ans.indexOf('\n');
        if (nl > 0) ans = ans.substring(0, nl).trim();
        if (ans.length() > 120) ans = ans.substring(0, 120);
        return ans.trim();
    }

    private static String sortLetters(String s) {
        char[] cs = s.toCharArray();
        java.util.Arrays.sort(cs);
        StringBuilder sb = new StringBuilder();
        char last = 0;
        for (char c : cs) {
            if (c == last) continue;
            sb.append(c);
            last = c;
        }
        return sb.toString();
    }
}

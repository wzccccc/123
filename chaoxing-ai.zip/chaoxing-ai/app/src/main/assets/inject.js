/* 超星答题·免卡密 — H5 答题页注入脚本
 * 由 WebHook 通过 evaluateJavascript 注入；桥对象名 window.CxAiFree
 * 只做三件事：找题干 → 找选项 → 调 Java 拿答案 → 点选
 */
(function () {
    if (window.__cxaiInstalled) {
        try { window.__cxaiScan(); } catch (e) {}
        return;
    }
    window.__cxaiInstalled = true;

    var BRIDGE_NAME = '__BRIDGE_NAME__';
    var BRIDGE = window[BRIDGE_NAME] || null;
    var DONE = new WeakSet();

    /* 可配置的 DOM 选择器（不同版学习通 H5 页结构会变，改这里即可） */
    var CFG = {
        block: [
            '.TiMu', '.timu', '.question', '.questionLi', '[class*="question"]',
            '[class*="TiMu"]', '[class*="timu"]', '[class*="topic"]', '[id*="question"]'
        ],
        option: [
            '.option', '.answer', '.answerBg', '.choice', '[class*="option"]',
            '[class*="answerLi"]', 'li', 'label'
        ],
        stem: ['.Zy_TItle', '.stem', '[class*="stem"]', '[class*="title"]', '.questionTitle', 'p']
    };

    function log(msg) {
        try {
            if (BRIDGE && BRIDGE.log) BRIDGE.log('[js] ' + msg);
        } catch (e) {}
    }

    function norm(s) {
        return String(s || '')
            .replace(/\s+/g, '')
            .replace(/[，。；：、,.;:!?"'“”‘’（）()【】\[\]<>《》\/\\|~`^*+=_-]/g, '');
    }

    function textOf(el) {
        if (!el) return '';
        var t = el.innerText || el.textContent || '';
        return String(t).replace(/\u00a0/g, ' ').trim();
    }

    function queryAll(root, selectors) {
        var out = [];
        for (var i = 0; i < selectors.length; i++) {
            var list;
            try { list = root.querySelectorAll(selectors[i]); } catch (e) { continue; }
            for (var j = 0; j < list.length; j++) {
                if (out.indexOf(list[j]) < 0) out.push(list[j]);
            }
        }
        return out;
    }

    /* 题干：优先 block 内的标题类节点，退化为 block 自身文本去掉选项文本 */
    function stemOf(block, optionTexts) {
        var cands = queryAll(block, CFG.stem);
        var best = '';
        for (var i = 0; i < cands.length; i++) {
            var t = textOf(cands[i]);
            if (t.length < 4) continue;
            var isOpt = false;
            for (var k = 0; k < optionTexts.length; k++) {
                if (optionTexts[k] && norm(t).indexOf(norm(optionTexts[k])) === 0) { isOpt = true; break; }
            }
            if (isOpt) continue;
            if (t.length > best.length) best = t;
        }
        if (!best) {
            var all = textOf(block);
            for (var m = 0; m < optionTexts.length; m++) {
                if (optionTexts[m]) all = all.split(optionTexts[m]).join(' ');
            }
            best = all.replace(/\s+/g, ' ').trim();
        }
        return best.length > 600 ? best.substring(0, 600) : best;
    }

    /* 选项：radio/checkbox 的父节点 + 选项容器类名 */
    function optionsOf(block) {
        var res = { nodes: [], texts: [], keys: [], type: 'single' };
        var inputs = block.querySelectorAll('input[type=radio],input[type=checkbox]');
        for (var i = 0; i < inputs.length; i++) {
            var inp = inputs[i];
            if (inp.type === 'checkbox') res.type = 'multi';
            var holder = inp.closest('label,li,.option,div') || inp.parentNode;
            var t = textOf(holder);
            if (!t || t.length > 300) continue;
            res.nodes.push(holder);
            res.texts.push(t);
            res.keys.push(String.fromCharCode(65 + res.texts.length - 1));
        }
        if (!res.texts.length) {
            var cands = queryAll(block, CFG.option);
            for (var j = 0; j < cands.length; j++) {
                var c = cands[j];
                if (c.querySelector('input[type=radio],input[type=checkbox]')) continue;
                var tx = textOf(c);
                if (!tx || tx.length < 1 || tx.length > 300) continue;
                if (c.querySelectorAll('li,div,p').length > 2) continue;
                if (res.texts.indexOf(tx) >= 0) continue;
                res.nodes.push(c);
                res.texts.push(tx);
                res.keys.push(String.fromCharCode(65 + res.texts.length - 1));
            }
        }
        return res;
    }

    /* 答案 → 要点的下标集合 */
    function pick(opts, answer) {
        var ans = norm(answer).toUpperCase();
        var out = [];
        if (!ans) return out;

        if (/^[A-H]{1,8}$/.test(ans)) {
            for (var i = 0; i < ans.length; i++) {
                var idx = ans.charCodeAt(i) - 65;
                if (idx >= 0 && idx < opts.nodes.length) out.push(idx);
            }
            if (out.length) return out;
        }

        for (var j = 0; j < opts.texts.length; j++) {
            var o = norm(opts.texts[j]);
            if (!o) continue;
            if (o === ans || o.indexOf(ans) === 0 || ans.indexOf(o) === 0) out.push(j);
        }
        if (out.length) return out;

        /* 判断题兜底 */
        var judgeTrue = /^(对|正确|是|T|TRUE|√|YES|Y)$/.test(ans);
        var judgeFalse = /^(错|错误|否|F|FALSE|×|X|NO|N)$/.test(ans);
        if (judgeTrue || judgeFalse) {
            for (var k = 0; k < opts.texts.length; k++) {
                var s = norm(opts.texts[k]);
                if (judgeTrue && /^(对|正确|是|√|T|TRUE)$/.test(s)) out.push(k);
                if (judgeFalse && /^(错|错误|否|×|X|F|FALSE)$/.test(s)) out.push(k);
            }
        }
        return out;
    }

    /* 模拟人手：先位移事件再点击，并把点击错开随机间隔，避免"同一毫秒批量选中"的特征 */
    function fire(node) {
        if (!node) return;
        try { node.scrollIntoView({ block: 'center' }); } catch (e) {}
        var inp = node.querySelector ? node.querySelector('input[type=radio],input[type=checkbox]') : null;
        var target = inp || node;
        var x = 0, y = 0;
        try {
            var r = target.getBoundingClientRect();
            x = Math.round(r.left + r.width / 2);
            y = Math.round(r.top + r.height / 2);
        } catch (e) {}
        try {
            ['pointerover', 'pointerenter', 'pointerdown', 'mousedown', 'pointerup', 'mouseup']
                .forEach(function (t) {
                    try {
                        target.dispatchEvent(new MouseEvent(t, {
                            bubbles: true, cancelable: true, clientX: x, clientY: y
                        }));
                    } catch (e) {}
                });
        } catch (e) {}
        try {
            ['touchstart', 'touchend'].forEach(function (t) {
                try {
                    target.dispatchEvent(new TouchEvent(t, { bubbles: true, cancelable: true }));
                } catch (e) {}
            });
        } catch (e) {}
        try {
            if (inp && !inp.checked) inp.click();
            node.click();
            if (inp) inp.dispatchEvent(new Event('change', { bubbles: true }));
        } catch (e) {
            log('click fail ' + e);
        }
    }

    function processBlock(block) {
        if (!block || DONE.has(block)) return;
        var opts = optionsOf(block);
        if (!opts.texts.length) return;
        var stem = stemOf(block, opts.texts);
        if (!stem || norm(stem).length < 4) return;

        var answer = '';
        try {
            answer = BRIDGE.answer(stem, JSON.stringify(opts.texts), opts.type);
        } catch (e) {
            log('bridge fail ' + e);
            return;
        }
        if (!answer || answer === 'NONE') return;

        var picked = pick(opts, answer);
        if (!picked.length) {
            log('answer unmapped: ' + answer + ' | ' + stem.substring(0, 30));
            return;
        }
        DONE.add(block);
        for (var i = 0; i < picked.length; i++) {
            (function (n, delay) {
                setTimeout(function () { fire(n); }, delay);
            })(opts.nodes[picked[i]], 350 + Math.random() * 1100 + i * 180);
        }
        log('filled ' + answer + ' -> ' + stem.substring(0, 24));
    }

    function scan() {
        var blocks = queryAll(document, CFG.block);
        for (var i = 0; i < blocks.length; i++) {
            var b = blocks[i];
            /* 只要最外层题目容器，避免同一题被选中多次 */
            var parentBlock = b.parentNode && b.parentNode.closest ? b.parentNode.closest(CFG.block.join(',')) : null;
            if (parentBlock && parentBlock !== b) continue;
            try { processBlock(b); } catch (e) { log('scan fail ' + e); }
        }
    }
    window.__cxaiScan = scan;

    var timer = null;
    function schedule() {
        if (timer) clearTimeout(timer);
        timer = setTimeout(function () {
            timer = null;
            try { scan(); } catch (e) {}
        }, 700);
    }

    try {
        var ob = new MutationObserver(schedule);
        ob.observe(document.documentElement, { childList: true, subtree: true, characterData: true });
    } catch (e) {}

    /* 首次 + 页面结构变化后的若干次补扫 */
    schedule();
    var n = 0;
    var iv = setInterval(function () {
        n++;
        scan();
        if (n > 12) clearInterval(iv);
    }, 1500);

    log('injected ' + location.href);
})();

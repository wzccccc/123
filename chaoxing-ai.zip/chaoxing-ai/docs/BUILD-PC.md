# 电脑端构建速查（Android Studio）

## 一、卡在「Android SDK path not specified」

这个弹窗不是报错，只是第一次打开时 AS 找不到 SDK 目录。三种填法，任选：

### 1. 让它自己下载（推荐，全新安装）

点输入框右侧的**文件夹图标** → 选一个**纯英文、无空格**的空目录，例如：

| 系统 | 建议路径 |
| --- | --- |
| Windows | `D:\Android\Sdk` |
| macOS | `/Users/<你>/Library/Android/sdk` |
| Linux | `/home/<你>/Android/Sdk` |

Windows 上直接新建 `D:\Android\Sdk` 就行，选完点 **OK**，AS 会自动下载 SDK 并装好基础组件（首次约 1~2 GB）。

### 2. 已经装过 SDK，只是它没找到

Windows 默认在 `C:\Users\<用户名>\AppData\Local\Android\Sdk`（`AppData` 是隐藏目录，直接把整条路径粘进输入框即可）。
macOS：`~/Library/Android/sdk`。

### 3. 先跳过，稍后设置

点 **Cancel** → 主界面 **More Actions → SDK Manager** 选路径，效果一样。
或者手动在工程根目录建 `local.properties`：

```properties
sdk.dir=D\:\\Android\\Sdk      # Windows（注意双反斜杠或改用单斜杠）
# sdk.dir=/home/you/Android/Sdk   # macOS / Linux
```

## 一·B、如果弹窗里还多了一个红框「Select Java JDK」

说明这次安装没检测到自带的 JBR（常见于绿色版/解压版、或用 zip 包安装的 AS）。
**不用另外装 JDK**，直接指向 Android Studio 自带的 JBR 即可：

| 安装方式 | JDK 路径 |
| --- | --- |
| Windows 安装包默认 | `C:\Program Files\Android\Android Studio\jbr` |
| Windows 解压版 | `<解压目录>\android-studio\jbr` |
| JetBrains Toolbox | `C:\Users\<你>\AppData\Local\Programs\Android Studio\jbr` |
| macOS | `/Applications/Android Studio.app/Contents/jbr/Contents/Home` |
| Linux | `/opt/android-studio/jbr`（snap 装在 `/snap/android-studio/current/android-studio/jbr`） |

验证方法：这个目录下必须有 `bin\java.exe`（Windows）或 `bin/java`。
确认后把路径粘进 **Select Java JDK** 输入框。

如果上述目录根本不存在（有的精简版删掉了 JBR），装一个 JDK 17：

- 微软 OpenJDK 17（有 MSI 安装包，最省事）
- 或 Adoptium Temurin 17

装完把 JDK 安装根目录填进去，例如 `C:\Program Files\Microsoft\jdk-17.0.13.11-hotspot`。
**别选 JDK 8 / 11**：AGP 8.5.2 要求 JDK 17 以上。

## 一·C、报 `Unable to access Android SDK add-on list`

这是**网络问题**，不是配置错：首次运行向导要去 `dl.google.com` 拉 SDK 组件清单，国内直连经常超时。

三种解法，按快慢排：

### 解 1：走代理（有梯子/Clash/v2rayN 的话 1 分钟）

点 **Setup Proxy** → 选 **Manual proxy configuration** → HTTP：

```
Host name: 127.0.0.1
Port number: 7890        ← Clash 默认；v2rayN 常见 10809/10808；SS 常见 1080
```

勾上 `Check connection` 填 `https://dl.google.com` 测试，通了就 OK，向导继续。

常见坑：

- 当前选的是 **Auto-detect proxy settings** + 空 PAC 地址 → 一定失败，必须切到 **Manual proxy configuration**。
- 端口不是 80：Clash `7890`、v2rayN `10809`、SS/SSR `1080`，以你客户端里「HTTP 端口」为准。
- 代理开的是 **TUN / 虚拟网卡模式**（全局接管流量）时，反而应该选 **No proxy**——流量在网络层就被接管了，再填 HTTP 代理会绕错。
- 代理带密码就填 Login / Password，并勾 Remember。

### 解 1·B：手动装 SDK（不用代理，10 分钟）

1. 浏览器打开腾讯云镜像 `https://mirrors.cloud.tencent.com/AndroidSDK/`
2. 下载这三个 zip：
   - `platform-34_r03.zip` → 解压到 `D:\AndroidSdk\platforms\android-34\`
   - `build-tools_r34-windows.zip` → 解压到 `D:\AndroidSdk\build-tools\34.0.0\`
   - `platform-tools-latest-windows.zip` → 解压到 `D:\AndroidSdk\platform-tools\`
3. 目录结构必须是这样（`source.properties` 要直接躺在版本目录里）：

```
D:\AndroidSdk\
├── platforms\android-34\        (android.jar、source.properties …)
├── build-tools\34.0.0\          (aapt2.exe、d8.bat、source.properties …)
└── platform-tools\              (adb.exe …)
```

4. 回到向导，选 **Select existing SDK** → 路径填 `D:\AndroidSdk`。

### 解 1·C：干脆不装 SDK，用 GitHub Actions 云构建

电脑上只留一个浏览器即可：把工程推到 GitHub 仓库，`.github/workflows/build-apk.yml` 会在云端用预装好的 SDK 编译，产物在 Actions → Artifacts 下载。见 [INSTALL.md](INSTALL.md) 第 1 节方式 A。

## 二、SDK 里必须有这两个组件

SDK Manager → **SDK Platforms** 勾 `Android 14.0 (API 34)`；
**SDK Tools** 勾 `Android SDK Build-Tools 34.0.0`（顺带装 `Android SDK Platform-Tools`）。
本工程 `compileSdk = 34`、`minSdk = 24`，少一个都会 Sync 失败。

## 三、打开工程

`File → Open` → 选 `chaoxing-ai` **目录**（不是里面的某个文件）→ 信任项目 → 等 Gradle Sync。

工程已经配好：

- `gradle/wrapper/gradle-wrapper.properties` → Gradle 8.7
- `settings.gradle.kts` → 阿里云镜像 + google + mavenCentral + api.xposed.info
- `app/build.gradle.kts` → AGP 8.5.2、`compileSdk 34`、release 直接挂 debug 签名

## 四、Sync / Build 常见报错

| 报错 | 原因 | 处理 |
| --- | --- | --- |
| `SDK location not found` | 没建 `local.properties` | 按第一节第 3 种方式写一行 `sdk.dir=` |
| `Failed to find target with hash string 'android-34'` | 没装 Platform 34 | SDK Manager 勾上重试 |
| `Could not resolve de.robv.android.xposed:api:82` | api.xposed.info 拉不动 | 浏览器下载 `https://api.xposed.info/de/robv/android/xposed/api/82/api-82.jar`，放到 `app/libs/api-82.jar`（工程已内置本地兜底，无需改代码） |
| `Could not resolve com.android.tools.build:gradle:8.5.2` | 镜像缺版本 | 临时把 `build.gradle.kts` 里版本改成 `8.4.2` 或 `8.6.1` |
| `Gradle wrapper jar missing` | 仓库里只带了 properties，没带二进制 jar | 弹窗点确定让它生成；或在 AS 的 Terminal 里 `gradle wrapper --gradle-version 8.7` |
| `Unsupported class file major version 65` | Gradle 跑在 JDK 21 上但版本太老 | 已经是 8.7，若还报就 `Settings → Build Tools → Gradle → Gradle JDK` 选 **17** |
| `AGP 8.5.2 is too old for this IDE` | 新版 AS 提示升级 | 忽略提示即可；要消掉警告就升到 AS 推荐的 AGP 并同步改 Gradle 版本 |
| 路径含中文导致莫名失败 | Windows 用户名/目录是中文 | 工程和 SDK 都放到纯英文路径下 |

## 五、出包

`Build → Build Bundle(s)/APK(s) → Build APK(s)`

产物：

```
app/build/outputs/apk/debug/app-debug.apk          # 调试版，直接可装
```

想要 release（体积略小、同样已签好名）：

```bash
gradlew assembleRelease
# app/build/outputs/apk/release/app-release.apk
```

## 六、装到手机

微信/QQ 传 apk → 手机点击安装（允许「安装未知应用」）→ 之后按
[INSTALL.md](INSTALL.md) 第 3 节配置 API、第 4 节验证日志。

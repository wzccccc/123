# 检测与隐藏：原版 vs 改版

> **证据边界**：原模块（`Xposed-Modules-Repo/com.yinshibai.chaoxingx`）是闭源分发的 APK，仓库里只有 `README.md / SUMMARY / SCOPE`，没有源码也没有 APK。
> 所以凡涉及原版内部实现的结论，下文一律标【推断】；标【可验证】的才是能直接看到的。
> 改版这边全部标了文件路径，可以逐行核对。

---

## 1. 学习通到底检测什么

按「被检测的位置」分四层，隐藏要一层层过，缺一层就漏：

| 层 | 检测手段 | 典型实现 |
| --- | --- | --- |
| 进程内静态 | 类加载器扫 `de.robv.android.xposed.XposedBridge`、`LSPosed` 类；扫 `/proc/self/maps` 里的 `libxposed_art.so`、可疑 dex 路径；`File.exists("/system/framework/XposedBridge.jar")`；`PackageManager` 查模块包名 / LSPosed 管理器包名 | 启动时一次 + 考试前一次 |
| 进程内动态 | `new Throwable().getStackTrace()` 看有没有 xposed 帧；反射比对方法 entrypoint；`Debug.isDebuggerConnected()`；检测 `XposedBridge` 常量池 | 关键函数调用时 |
| 环境 | root（`su` 路径、`ro.build.tags`）、模拟器、多开/分身、无障碍服务、悬浮窗、截屏录屏、VPN/代理、开发者选项、系统时间跳变 | 登录时 + 答题页 |
| H5 前端 | `window` 上遍历可疑全局对象；`event.isTrusted` 校验；DOM 被外部改动（自身也会挂 MutationObserver）；点击前必须有 pointer/touch 序列；题目停留时长 | 答题页 JS |
| 服务端 | 答题间隔分布、每题只点一次且零回改、切屏次数上报、心跳中断、设备指纹突变、答案与题库命中率异常 | 交卷后风控 |

关键点：**只有第 1、2 层能在模块里用 Java hook 解决**；第 3 层要靠 Zygote 层方案（Shamiko/Zygisk）；第 4 层只能靠「像人」的行为；第 5 层根本不在客户端。

---

## 2. 原版怎么隐藏（【推断】，附判断依据）

能确认的事实：

- 【可验证】仓库 description = 「学习通 考试击破」，`homepage` 指向 `Dingtaiqi/com.fxxkchaoxing.tool`（同样只有 README）。
- 【可验证】你截图里的 UI：`运行中` 状态、`激活码 + 已验证/购买`、`题库答案作为 AI 提示词`、`本地缓存 82 道题`、`仅学习通内答题`。
- 结论：它有**卡密服务器**，也就是说存在「设备 → 作者服务器」的上报链路，服务器端可以按设备/卡密封禁——这是「反白嫖」，不是「反检测」，但常被混为一谈。

按国内这类模块的通用做法，它大概率做了下面几件事（**均为推断**）：

| 手段 | 作用层 | 说明 |
| --- | --- | --- |
| 只勾学习通作用域、不开全局 | LSPosed | 减少注入面，非作用域 App 看不到模块 |
| `PackageManager` 过滤自己包名 | 模块内 | 挡 `getInstalledPackages()` 扫描 |
| `File.exists` 过滤 xposed/root 路径 | 模块内 | 挡静态路径探测 |
| `getStackTrace` 帧过滤 | 模块内 | 挡动态栈探测 |
| 配合 Shamiko / Zygisk 隐藏 | Zygote | 挡 `/proc/self/maps`、模块文件、LSPosed 目录 |
| 答题随机延时 / 模拟点击 | 行为 | 挡「毫秒级批量选中」的特征 |
| 设备指纹 + 卡密绑定 | 服务端 | 限制一码多机 |

**它为什么可能「更干净」**：闭源 + 卡密服务器意味着作者会持续针对学习通的检测更新（这是付费模块的卖点）；同时它可以把 maps 级隐藏的责任外包给 Shamiko。

**它的隐藏也有代价**：卡密服务器同时是最大攻击面——能封你、能改你的 prompt、能知道你答了哪些题。

---

## 3. 改版第一版（v1.0.0）的暴露点

这些是**我写的时候客观存在**的，不是猜的：

| 暴露点 | 位置 | 严重度 |
| --- | --- | --- |
| JS 桥固定名 `window.CxAiFree` | `WebHook.Bridge` 注册名 | 高：页面一行 `typeof window.CxAiFree` 即可确认被注入 |
| DOM 标记 `el.__cxaiDone` | `inject.js` | 高：属性可枚举，前端可扫 |
| 固定点击间隔 120ms + i×80ms | `NativeHook` | 中：机器特征明显 |
| 无栈/路径/包名隐藏 | — | 高：静态检测直接过 |
| Provider authority 固定 | `Const.AUTHORITY` | 中：`resolveContentProvider()` 一行探测 |
| 日志 tag / 类名含 `cxai`、`chaoxingx` | 全局 | 低：字符串扫描可命中 |

---

## 4. 改版现在（v1.0.2）做了什么

新增 `hooks/StealthHook.java`，默认开启（设置页「反检测」开关）：

1. **栈过滤**：hook `Throwable.getStackTrace()`，剔除类名/方法名/文件名包含
   `xposed / lsposed / edxposed / epic / sandhook / riru / zygisk / shamiko / magisk / substrate / cxai / chaoxingx` 的帧。
2. **路径隐藏**：hook `File.exists()` 与 `File.canRead()`，对 13 条已知路径（`XposedBridge.jar`、`libxposed_art.so`、`/data/adb/magisk`、各 `su` 路径等）返回 false。
3. **包名隐藏**：hook `ApplicationPackageManager.getInstalledPackages/getInstalledApplications` 过滤本模块；`getPackageInfo(本模块)` 直接抛 `NameNotFoundException`。

WebView 侧（`WebHook` + `inject.js`）：

4. **桥名随机化**：每次进程启动为每个 WebView 生成 `__cx<10位hex>`，脚本通过占位符 `__BRIDGE_NAME__` 注入，页面拿不到固定名。
5. **不落 DOM 属性**：`__cxaiDone` → `WeakSet`（外部不可枚举）。
6. **点击像人**：先派发 `pointerover/pointerenter/pointerdown/mousedown/pointerup/mouseup` + `touchstart/touchend`，再 `click()`；多选之间延时 `350 + rand*1100 + i*180` ms。

原生页（`NativeHook`）：

7. 点击延时改为 `320 + rand*1000 + i*180` ms，不再固定。

---

## 5. 八个检测面对比

| 检测面 | 原版（推断） | 改版 v1.0.2 | 谁更稳 |
| --- | --- | --- | --- |
| `getInstalledPackages` 扫模块 | 过滤 | 已过滤 | 平 |
| `File.exists` 查 xposed 路径 | 过滤 | 已过滤（13 条） | 平 |
| `getStackTrace` 查 xposed 帧 | 过滤 | 已过滤 | 平 |
| `/proc/self/maps` 扫段 | Shamiko 级隐藏 | **未处理**（Java 层做不干净） | 原版 |
| H5 `window` 全局探测 | 未知 | 桥名随机、DOM 无痕 | 改版（若有做则平） |
| `event.isTrusted` 校验 | 未知 | **仍为 false**（JS 无法伪造） | 原版（若用原生注入则优） |
| 点击节奏特征 | 有随机延时 | 已随机化 | 平 |
| Provider / 组件指纹 | 无 Provider | **authority 可被探测** | 原版 |
| 服务端行为风控 | 一样过不了 | 一样过不了 | 平 |
| 卡密封禁能力 | 作者可远程封 | 无（也没有远程后门） | 看你怕谁 |

---

## 6. 仍然过不去的四件事

1. **`/proc/self/maps`**：LSPosed 的 dex 段与 `liblspd` 需要在 Zygote 层隐藏。装 **Shamiko**（Magisk + Zygisk 前提）并在 LSPosed 里开启「隐藏」是唯一现实解；纯 Java hook 读 maps 的路径太多（`Os.read`、`IoBridge`、`FileChannel`、native），拦不全。
2. **`event.isTrusted`**：JS 构造的事件永远是 `false`。要做到 `true` 只有两条路——`InputManager.injectInputEvent`（需 root/系统权限）或无服务端校验的页面（多数学习通 H5 不校验，但不能赌）。
3. **答题节奏**：一页 20 题、每题一次点击、零犹豫、从不回改——随机延时只降低特征，消不掉。服务端做时序聚类照样能挑出来。
4. **组件指纹**：学习通只要 `getPackageManager().resolveContentProvider("com.yinshibai.chaoxingx.free.bank", 0)` 即知模块存在。要修得改成非 exported + 学习通进程内自建通道（牺牲可用性），或每次构建随机 authority（提高成本，不根治）。

---

## 7. 一句话结论

- **原版**：把「进程级隐藏」交给生态（LSPosed + Shamiko）并可能做了栈/路径/包名过滤，加上卡密服务器的持续对抗 —— 对 **maps 级扫描**更可能过关；代价是数据与生杀权都在作者服务器上。
- **改版**：Java 层隐藏齐了（栈 / 路径 / 包名）+ JS 桥无固定指纹 + 点击像人，但 **maps 级**、**isTrusted**、**Provider 指纹** 三处仍会露，且完全依赖你自己装 Shamiko 来补齐第一项。
- 两者都**过不了服务端行为风控**——那是统计问题，不是客户端问题。

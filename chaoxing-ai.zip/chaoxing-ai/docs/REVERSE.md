# 换学习通版本后怎么重新定位 Hook 点

本模块刻意**不写死混淆类名**，所以 90% 的版本更新不需要改代码。
下面这套流程用于剩下 10%：网络层拦截失效、H5 页面结构大改、原生页识别不准。

## 0. 准备

```bash
# 从设备拉取已安装的 APK
adb shell pm path com.chaoxing.mobile
adb pull /data/app/~~xxxx/com.chaoxing.mobile-xxxx/base.apk chaoxing.apk

# 反编译（jadx 1.5+）
jadx -d cx_out --no-res chaoxing.apk
```

## 1. 网络层：确认是否 OkHttp

```bash
# 看依赖里有没有 okhttp
unzip -l chaoxing.apk | grep -i okhttp
grep -rl "okhttp3/RealInterceptorChain" cx_out | head
```

- 有 `okhttp3/RealInterceptorChain` → `NetHook` 通用拦截直接生效，无需改动。
- 只有 `okhttp3/internal/http/RealInterceptorChain`（老版本 3.x）→ 已在代码里兼容。
- 完全没有 okhttp（走 Cronet/自研）→ 用 `grep -rn "HttpURLConnection" cx_out` 找到封装类，
  在 `NetHook` 里仿照 `hookChain()` 增加一个 hook。

## 2. 题目接口：确认字段名

```bash
# 学习通答题接口一般在 mooc2-ans / exam / work 下
grep -rn "questionName\|questionType\|optionList\|exam-ans" cx_out --include=*.java | head -40
```

把新出现的字段名补进 `PayloadScanner` 的三个白名单数组：

- `STEM_KEYS`：题干字段
- `OPTION_ARRAY_KEYS`：选项数组字段
- `OPTION_TEXT_KEYS` / `OPTION_KEY_KEYS`：选项文本与字母字段

判断标准：字段值是「一整句带问号的话」→ 题干；是 `[{...},{...}]` 且每项有短文本 → 选项。

## 3. H5 答题页：抓 DOM

在设备上打开答题页，用 Chrome `chrome://inspect` 远程调试 WebView，控制台执行：

```js
// 找题目容器
[...document.querySelectorAll('div')]
  .filter(d => d.querySelectorAll('input[type=radio],input[type=checkbox]').length >= 2)
  .slice(0, 5)
  .forEach(d => console.log(d.className, '|', d.innerText.slice(0, 40)));

// 看选项容器类名
document.querySelectorAll('input[type=radio]')[0]
  .closest('label,li,div').className
```

把结果写回 `assets/inject.js` 顶部：

```js
var CFG = {
    block:  ['.TiMu', ...你抓到的容器类名],
    option: ['label', ...你抓到的选项类名],
    stem:   ['.Zy_TItle', ...你抓到的题干类名]
};
```

## 4. 原生答题页：看 View 树

```bash
adb shell uiautomator dump /sdcard/ui.xml && adb pull /sdcard/ui.xml
grep -o 'resource-id="[^"]*"' ui.xml | sort -u | grep -i -E "option|answer|question|title"
```

把命中的 id 片段补进 `Const.STEM_ID_KEYS` / `Const.OPTION_KEYS`。
`NativeHook` 的基础判据是「同一个父容器下 ≥2 个带文本的可点控件 = 选项组」，
id 关键词只是加分项，所以多数情况不改也能用。

## 5. 调试手法

```bash
# 只看本模块日志
adb logcat -s CxAiFree:V
```

模块内「查看运行日志」界面会显示：

- `网络捕获题目 N 道 @url` —— 网络层提题是否成功
- `已注入答题脚本 @url` —— H5 注入是否成功
- `原生页已作答 A -> 题干…` —— 原生页点击是否成功
- `未找到 OkHttp 拦截点` —— 需要按第 1 步处理

## 6. 常见坑

| 现象 | 原因 | 处理 |
| --- | --- | --- |
| 日志里完全没有 `模块加载` | LSPosed 作用域没勾 / 进程没重启 | 勾作用域后强行停止学习通 |
| `未配置 Key` 但明明填了 | `xposedsharedprefs` 元数据丢失 | 检查 Manifest 里那条 meta-data |
| H5 页面有注入日志但不点 | 选择器没匹配上 | 按第 3 步改 `CFG` |
| 点错成别的控件 | 页面里有多组可点文本 | 收紧 `Const.OPTION_KEYS`，或给 `looksLikeOption` 加类名判断 |
| 答案字母对不上选项 | 选项被过滤导致下标错位 | 已修：`viable` 列表与选项一一对应 |

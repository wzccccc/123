# 学习通升级时怎么处理模块（要不要停？）

## 一句话

**不用停，但要先降级成「提示模式」再验证。** 这一点已经做成代码逻辑（`VersionGate`），
学习通 versionCode 一变化，模块自动进提示模式：照样求解、照样写日志，**绝不碰 UI**——
避免把「提交/交卷」误当成选项点掉。

---

## 为什么不是「必须停」

升级的连锁反应只有三件事，都不至于让学习通起不来：

| 变化 | 后果 | 会不会崩 |
| --- | --- | --- |
| 包名不变，LSPosed 作用域按包名绑定 | 模块继续注入，不用重新勾 | 不会 |
| 学习通内部类/方法改名 | `NetHook` 走 `findClassIfExists`，找不到只是少一条能力 | 不会 |
| H5 页面 DOM 改结构 | `inject.js` 选择器不匹配 → 静默不点 | 不会 |
| 原生页布局改 | `NativeHook` 启发式可能选错容器 → **误点风险** | 不会（但危险） |

另外所有 Hook 都挂在**框架类**上（`Application.attach`、`WebView.loadUrl`、`WebViewClient.onPageFinished`、`Activity.onResume`、`Throwable.getStackTrace`、`File.exists`、`ApplicationPackageManager.*`），
这些签名由 Android 版本决定，不受学习通改版影响；`MainHook.boot()` 整体包在 try/catch 里，
hook 失败只写日志，不会连累学习通启动。

**所以真正的风险不是崩溃，而是「静默失效」和「误点」。**

---

## 标准流程

### 更新前（1 分钟）

```bash
# 1. 备份旧版 APK，方便回滚
adb shell pm path com.chaoxing.mobile
adb pull /data/app/~~xxxx/com.chaoxing.mobile-xxxx/base.apk chaoxing-old.apk

# 2. 关掉商店自动更新（应用商店里对「学习通」关闭自动更新）
#    否则半夜自动升级、早上直接开考，你没有任何验证窗口
```

模块**不用**停，也不用取消 LSPosed 作用域。

### 更新后第一次打开

1. 打开模块 → 顶部会显示
   `学习通 x.y.z (1234) · 未适配 → 当前为提示模式`
   —— 说明闸门生效，现在只提示不点选。
2. 进答题页做一题，看「查看运行日志」：

```
目标版本 6.x.x(1234) 已适配=false 提示模式=true
【提示模式】B -> 下列哪项属于……（当前学习通版本未适配，未点选）
```

3. 对照页面看：日志里的答案字母是不是你要选的那一项。

- **对** → 点「标记为『当前版本已适配』」，重启学习通，之后恢复真实点选。
- **不对**（字母全错位）→ 说明选项顺序识别错了，按 [REVERSE.md](REVERSE.md) 第 3/4 节修选择器，别点适配。

### 常见情况处置

| 现象 | 处置 |
| --- | --- |
| 日志里没有 `模块加载` | LSPosed 作用域丢了 → 重勾学习通 → 强行停止再开 |
| 有 `已注入答题脚本` 但不点 | H5 结构变了 → 改 `inject.js` 顶部 `CFG` 三个选择器数组 |
| 显示 `未找到 OkHttp 拦截点` | 新版换了网络栈 → 按 REVERSE §1 补 hook；不影响 UI 点选 |
| 原生页识别不到选项 | 新 id 词补进 `Const.OPTION_KEYS` |
| 点错成「提交/下一题」 | 立刻开「提示模式」，收紧 `Const.OPTION_KEYS` 后重试 |

### 回滚

```bash
adb install -r -d chaoxing-old.apk     # -d 允许降级
```
或者在 LSPosed 里把学习通的作用域取消，模块即不再注入（学习通侧不受影响）。

---

## 什么情况下才真的要停模块

不是"因为更新"，而是这三种：

1. **学习通新版加了完整性/反调试校验**，模块注入后学习通启动即闪退 → 先关作用域，再按 REVERSE 调 Hook 点。
2. **考试页出现白屏/卡死**，且关掉模块就正常 → 同上，定位到具体 hook（通常是 `StealthHook` 的 `getStackTrace` 与新版加固冲突）。
3. **你正在被监考/人脸核验** —— 这类页面任何客户端注入都可能被判异常，规范做法是关模块、正常手动作答。

---

## 版本闸门的实现

`VersionGate.check()` 在 `MainHook.boot()` 里第一件事执行：

```java
PackageInfo pi = ctx.getPackageManager().getPackageInfo(Const.TARGET, 0);
verified = String.valueOf(pi.versionCode).equals(Cfg.s(Cfg.K_VERIFIED_VER, ""));
dryRun   = Cfg.b(Cfg.K_DRY_RUN, false) || !verified;
```

- `NativeHook.applyAnswer()`：`dryRun` 时只写日志，`return` 前不点任何控件
- `WebHook.Bridge.answer()`：`dryRun` 时返回空串，`inject.js` 收到空答案就不点

副作用：换机/降级/重装后 versionCode 变了也会进提示模式，点一次「已适配」即可，成本一次点击。

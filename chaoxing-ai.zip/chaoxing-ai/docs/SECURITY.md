# 安全性对比：原版（com.yinshibai.chaoxingx）vs 本重写版

先给结论，再逐项拆。

- **对「外部服务端 / 供应链」的信任**：本版明显更好——源码可审、构建可复现、数据只飞你自己填的那一个 AI 端点，可以填本地 Ollama 做到 0 外泄；原版是闭源 APK + 卡密服务器，你无法知道它上报了什么。
- **对「本机其它 App / 本地攻击者」的防护**：原版初始更好（卡密派生密钥加密配置、无 exported 组件），本版第一版有三个真实漏洞，**已在 v1.0.1 修掉**（下文 P0-1/2/3）。
- **被目标 App 检测/封号的风险**：两边同级，本版还略差——没有做任何 Xposed 痕迹隐藏。

---

## 1. 逐项对比

| 维度 | 原版 | 本重写版（v1.0.1） | 谁更安全 |
| --- | --- | --- | --- |
| 代码可审计 | 闭源 APK，仅 Xposed 仓库分发 | 全量 Java/JS 源码，可 diff、可自建 | **本版** |
| 数据流向 | 题干 + 设备信息可能上报作者服务器（不可验证） | 只发给你配置的 `ai_base`；可填本地模型 | **本版** |
| 远程控制面 | 卡密服务器可下发配置/封禁/改 prompt，属远程后门能力 | 无任何远程配置、无心跳、无吊销 | 本版（无后门，但也无吊销手段） |
| API Key 存储 | 卡密派生密钥加密（推测） | 明文 SharedPreferences + `xposedsharedprefs` | 原版 |
| 组件暴露面 | 无 exported 组件 | `BankProvider` exported，**第一版任意 App 可读写题库/日志** | 原版 → 本版已修 |
| WebView 注入面 | 未知（闭源） | 第一版用 `contains` 匹配域名 → `chaoxing.com.evil.tld` 可拿到 JS 桥 | 本版已修 |
| 传输安全 | 未知 | 第一版允许用户填 `http://` → 明文传 Key 与题干 | 本版已修（禁明文，仅放行本地模型） |
| 权限面 | 需存储权限读写 sdcard 题库 | 只要 `INTERNET` + `ACCESS_NETWORK_STATE`，题库走 IPC | **本版** |
| 供应链风险 | 依赖作者 keystore 与更新渠道，无法独立验证 | 自己签名自己装，无更新器 | **本版** |
| Hook 痕迹 | 有（未公开） | 有：`de.robv.android.xposed.*` 在调用栈、`/proc/self/maps` 可见 | 原版（若做了隐藏） |
| 逻辑副作用 | 未知 | 原生页启发式可能误点「提交/下一题」 | 本版更差 |
| 资源耗尽 | 未知 | 题库 `find` 是 O(n) 全表 Dice 计算，最多 2 万条 | 两边都有，本版已限流 |

---

## 2. 本版第一版真实存在的三个漏洞（已修）

### P0-1：`BankProvider` 对全机开放（数据泄露 + 题库投毒）

`AndroidManifest.xml` 里 `android:exported="true"` 且没有权限保护，任何装在你手机上的 App 都能：

```bash
# 拉走你全部题库和题干
adb shell content query --uri content://com.yinshibai.chaoxingx.free.bank/export
# 灌 20 万条错误答案，让 AI/题库做错
adb shell content insert --uri content://com.yinshibai.chaoxingx.free.bank/entry \
  --bind stem:s:'任意题干' --bind answer:s:'Z'
# 清空题库 / 读日志（日志含题干原文）
adb shell content delete --uri content://com.yinshibai.chaoxingx.free.bank/entry --where "all"
```

**修法**：Provider 内用 `Binder.getCallingUid()` 取调用方包名，只放行 `com.yinshibai.chaoxingx.free` 与 `com.chaoxing.mobile`（`BankProvider.callerAllowed()`），并对入库字段加长度上限（`MAX_STEM=2000`、`MAX_ANSWER=500`、`MAX_ENTRIES=20000`）。

> 为什么不用 `android:permission`：学习通是别的签名，拿不到模块的签名级权限，只能用 UID 白名单。

### P0-2：WebView 域名判断用 `contains`（JS 桥可被钓鱼页劫持）

```java
// 旧：任意包含 "chaoxing.com" 的字符串都放行
u.contains("chaoxing.com")   // https://chaoxing.com.evil.tld  ← 通过
u.contains("edu.cn")         // https://fake-edu.cn           ← 通过
```

恶意页拿到 `window.CxAiFree` 后可以：读题库条数、用你的 Key 无限调用 `answer()` 烧额度、批量探测题库内容。

**修法**：`new URL(url).getHost()` + 后缀严格匹配（`host.equals(d) || host.endsWith("." + d)`），并且**移除 `file://` / `data:` 放行**。

### P0-3：允许明文 HTTP（Key 与题干裸奔）

旧版 `AiClient` 对用户填的 `http://api.xxx.com` 照发不误：同一个 WiFi 下抓包即可拿到你的 API Key 和全部考试题干。

**修法**：`AiClient.requireSecure()` 只放行 `https://`，`http://` 仅允许 `127.0.0.1 / localhost / 10.x / 192.168.x / 10.0.2.2`（本地模型）；同时 Manifest 加 `android:usesCleartextTraffic="false"` + `res/xml/network_security_config.xml`。

> 注意：真正生效的是 `requireSecure()`，因为 AI 请求发生在**学习通进程**里，学习通自己的 networkSecurityConfig 不受你控制。

---

## 3. 仍未处理的风险（本版依然弱于原版的地方）

1. **API Key 明文落盘**
   `cxai_free.xml` 里 `ai_key` 是明文。root 设备、`adb backup`、或被授予存储/备份能力的工具都能读。
   彻底修法：用 Android Keystore 的 AES-GCM 加密后再存（`KeyGenParameterSpec` + `Cipher`），解密只发生在 Hook 进程。
2. **无 Hook 隐蔽**
   学习通若扫 `/proc/self/maps` 查 `libxposed`、查 `XposedBridge` 类、查可疑栈帧，本版会命中。常见缓解是给模块加 App 级隐藏（对目标进程隐藏模块列表）或用 Shamiko 之类的外部方案——本项目没做。
3. **误点风险**
   `NativeHook` 用「同一父容器下 ≥2 个可点文本 = 选项组」的启发式。若考试页把「提交」和选项放在同一容器，理论上会点到提交。缓解：`clickNext()` 只匹配「下一题/下一页」文本；选项组超过 12 个直接放弃（`if (best.size() > 12) return;`）。
4. **题库查询复杂度**
   `BankProvider` 的 `find` 对全表做 Dice 相似度，O(n)。2 万条时单次约 2 万次 bigram 比对，在低端机上可能 100~300ms，发生在 Hook 进程里会拖慢答题页。修法：加长度+首两字哈希分桶，或改成前缀索引。
5. **无完整性/防篡改**
   任何能改 `/data/data/com.yinshibai.chaoxingx.free/shared_prefs` 的 root 工具都能把你的 `ai_base` 换成攻击者服务器（中间人拿题干+答案）。想彻底解决需要 `ai_base` 做签名校验或固定白名单。

---

## 4. 威胁模型建议

- **你担心的是「作者/第三方服务端看我的数据」** → 用本版，`ai_base` 填 `http://127.0.0.1:11434/v1`（本地 Ollama），整条链路 0 外泄。
- **你担心的是「手机里其它 App 搞我」** → v1.0.1 已补上 UID 白名单、严格域名匹配、禁明文；再补 Keystore 加密就基本齐了。
- **你担心的是「被学校/平台检测」** → 两边都不解决，本版甚至更明显；这类场景只能靠外部隐藏方案。

---

## 5. 变更记录

| 版本 | 安全相关变更 |
| --- | --- |
| v1.0.0 | 初版：无卡密、Provider 全开、`contains` 域名匹配、允许明文 HTTP |
| v1.0.1 | `BankProvider.callerAllowed()` UID 白名单 + 字段长度/条数上限；`hostAllowed()` 严格后缀匹配并禁 `file://`；`AiClient.requireSecure()` + `usesCleartextTraffic=false` + network_security_config |

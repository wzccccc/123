# 安装与使用教程（从零到能答题）

全程约 20 分钟。分五段：**拿 APK → 装环境 → 装模块 → 配 API → 验证**。

---

## 0. 前置条件自查

| 项目 | 要求 | 怎么确认 |
| --- | --- | --- |
| 手机 | 已 root | 有 Magisk / KernelSU / APatch 管理器图标 |
| 框架 | **LSPosed**（Zygisk 版）1.9.2 以上 | LSPosed 管理器能打开，且「模块」页可列出模块 |
| Zygisk | 开启 | Magisk → 设置 → 打开 Zygisk → 重启 |
| 目标 App | 学习通 `com.chaoxing.mobile` | 应用列表里有 |
| 可选 | Shamiko（隐藏 root / LSPosed 痕迹） | 见第 5 节 |

**没有 LSPosed 就先装框架**：Magisk → 设置开 Zygisk → 重启 → 下载 LSPosed Zygisk 版 zip → Magisk「从本地安装」→ 重启 → 打开 LSPosed 管理器。
KernelSU / APatch 用户装 **ZygiskNext** + LSPosed，步骤一样。

> 别用旧版 EdXposed，学习通这类带加固的 App 在上面容易起不来。

---

## 1. 拿到 APK（三选一）

### 方式 A：GitHub Actions 云构建（推荐，手机也能完成）

1. 把 `chaoxing-ai/` 整个目录推到一个 GitHub 仓库（private 也可以）。
2. 仓库里已有 `.github/workflows/build-apk.yml`，push 后自动构建。
3. 打开仓库 → **Actions** → 最新一次 `build-apk` → 页面底部 **Artifacts** → 下载 `cxai-free-apk.zip`。
4. 解压得到 `app-release.apk`（已用 debug 签名，可直接侧载）。

> 如果工程就在仓库根目录，删掉 workflow 里 `working-directory: chaoxing-ai` 那一行。

### 方式 B：Android Studio（有电脑）

```bash
# 打开 Android Studio → Open → 选中 chaoxing-ai 目录
# 等 Gradle Sync 完成 → Build → Build Bundle(s)/APK(s) → Build APK(s)
# 产物：app/build/outputs/apk/debug/app-debug.apk
```
或命令行：

```bash
cd chaoxing-ai
echo "sdk.dir=$ANDROID_HOME" > local.properties
gradle assembleRelease --no-daemon
```

### 方式 C：已有他人构建好的 APK

直接跳到第 2 节。**注意核对包名**必须是 `com.yinshibai.chaoxingx.free`，
否则模块的 `Const.MODULE_PKG`、Provider authority、`xposed_init` 都会对不上。

---

## 2. 安装模块

1. 手机上点开 `app-release.apk` → 允许「安装未知应用」→ 安装。
   桌面出现 **超星答题·免卡密**。
2. 打开 **LSPosed 管理器** → 底部 **模块** → 列表里应出现「超星答题·免卡密」。
   - 看不到 → 下拉刷新；仍没有 → 说明模块的 `xposedmodule` 元数据没生效，检查是否装的是别的包名。
3. 点进模块 → 打开右上角开关 → **勾选作用域** → 只勾 `学习通`（`com.chaoxing.mobile`）。
   - 不要勾系统应用、不要勾「全部应用」。
4. 回到 LSPosed → 右上角可能需要 **重启** 一次（软重启/重启手机）。

> 这一步只是"授权注入"，模块功能还没配。

---

## 3. 配置 API

打开桌面上的 **超星答题·免卡密**：

| 字段 | 填什么 | 示例 |
| --- | --- | --- |
| Base URL | OpenAI 兼容地址 | `https://api.deepseek.com/v1` |
| API Key | 你的 key | `sk-xxxxxxxx` |
| 模型名 | 模型 ID | `deepseek-chat` |

常见组合：

| 服务 | Base URL | 模型 |
| --- | --- | --- |
| DeepSeek | `https://api.deepseek.com/v1` | `deepseek-chat` |
| 通义千问 | `https://dashscope.aliyuncs.com/compatible-mode/v1` | `qwen-plus` |
| 智谱 | `https://open.bigmodel.cn/api/paas/v4` | `glm-4-flash` |
| 本地 Ollama（零外泄） | `http://127.0.0.1:11434/v1` | `qwen2.5:7b` |
| one-api / new-api 中转 | 你的中转地址 + `/v1` | 中转里配的模型名 |

填完点 **保存配置** → 点 **测试连通性** → 弹出 `OK 812ms :: ...` 即通。
报错对照：

| 报错 | 原因 |
| --- | --- |
| `HTTP 401` | Key 错或没带 `Bearer` |
| `HTTP 404` | Base URL 少了或多了 `/v1`，或模型名不存在 |
| `拒绝明文 HTTP` | 你填了 `http://` 且不是本地地址 → 换 `https://` |
| `Connection timed out` | 手机网络/代理问题；Ollama 要先在电脑上 `OLLAMA_HOST=0.0.0.0` 并放行端口 |

顶部状态显示 **运行中** 就对了。

---

## 4. 验证（关键，别跳过）

1. **强行停止学习通**（设置 → 应用 → 学习通 → 强行停止），再打开。
   - 不重启进程的话，模块不会加载。
2. 打开模块 → **查看运行日志**，应看到四条：
   ```
   模块加载: com.chaoxing.mobile/com.chaoxing.mobile
   已就绪 · 题库 0 条 · 自动答题=true
   拦截 okhttp3.RealInterceptorChain.proceed
   WebView 注入已安装
   原生页兜底已安装
   反检测已启用（栈过滤 / 路径隐藏 / 包名隐藏）
   目标版本 6.x.x(1234) 已适配=false 提示模式=true
   ```
3. **第一次一定是提示模式**（`提示模式=true`）。进学习通做一道题，日志会出：
   ```
   【提示模式】B -> 下列哪项属于……（当前学习通版本未适配，未点选）
   ```
   对照页面：字母对得上 → 回模块点 **「标记为『当前版本已适配』」** → 强行停止学习通再开 → 恢复真实点选。
   对不上 → 见第 6 节，先别点适配。
4. 再做一题，日志应变成：
   ```
   AI 作答: 下列哪项属于…… -> B
   原生页已作答 B -> 下列哪项属于……
   ```
   页面上选项被自动选中 = 成功。

---

## 5. 想降低被检测概率（可选）

1. 装 **Shamiko**（Magisk 模块），Magisk 设置里把「遵守 DenyList」关掉，Shamiko 生效。
2. LSPosed 里只勾学习通作用域；不要开「全局模式」。
3. 模块设置里保持 **反检测** 勾选。
4. 不要在考试/监考页使用——那类页面任何注入都可能被判定异常。

---

## 6. 常见问题

| 现象 | 原因 | 处理 |
| --- | --- | --- |
| LSPosed 模块列表里没有本模块 | 装错包名 / 未重启 LSPosed | 确认包名 `com.yinshibai.chaoxingx.free`，重启 |
| 日志为空 | 作用域没勾 / 学习通进程没重启 | 勾作用域 + 强行停止学习通 |
| 日志有 `模块加载` 但没有 `拦截 okhttp3…` | 该版本不用 OkHttp | 不影响 UI 点选；按 `docs/REVERSE.md` §1 补 hook |
| 提示模式解除后仍不点 | H5 选择器不匹配 | 按 `docs/REVERSE.md` §3 改 `inject.js` 的 `CFG` |
| 原生页识别不到选项 | 新版本 id 变了 | 把新 id 词补进 `Const.OPTION_KEYS` |
| 选错选项 | 选项组识别错（页面上有多组可点文本） | 立刻开「提示模式」，收紧 `Const.OPTION_KEYS` 再试 |
| 学习通启动闪退 | 新版加固与 `StealthHook` 的 `getStackTrace` 冲突 | LSPosed 取消作用域 → 关掉模块「反检测」→ 再试 |
| 题库条数一直是 0 | Provider 被拒 / 缓存开关关了 | 日志搜「拒绝 Provider 访问」；检查「启用本地缓存」 |
| 导入题库报格式错 | JSON 结构不对 | 需要 `{"items":[{"q":"题干","a":"答案","t":"single"}]}` |

---

## 7. 卸载 / 回滚

模块**不修改学习通 APK**，卸载干净利落：

1. LSPosed → 模块 → 取消学习通作用域（或直接关闭模块开关）。
2. 卸载「超星答题·免卡密」。
3. 强行停止学习通，恢复正常。

学习通本身不需要重装，也不会残留改动。

---

## 8. 一页速查

```
① LSPosed 装好 + Zygisk 开
② 装 app-release.apk
③ LSPosed → 模块 → 启用 → 作用域只勾学习通
④ 模块里填 Base URL / Key / 模型 → 保存 → 测试连通性
⑤ 强行停止学习通 → 打开 → 日志看到 6 条 install
⑥ 做一题看提示模式日志 → 对上就点「已适配」→ 重启学习通
⑦ 正式自动点选
```

#!/usr/bin/env bash
# 一键打包：需要本地已装 JDK17 + Android SDK（ANDROID_HOME 已配置）+ gradle 8.x
set -euo pipefail
cd "$(dirname "$0")/.."

if [ ! -x "$(command -v gradle)" ]; then
  echo "[!] 未找到 gradle，可先执行: gradle wrapper --gradle-version 8.7，再改用 ./gradlew"
  exit 1
fi

: "${ANDROID_HOME:=${ANDROID_SDK_ROOT:-}}"
if [ -z "$ANDROID_HOME" ]; then
  echo "[!] 请先配置 ANDROID_HOME 指向 Android SDK"
  exit 1
fi
echo "local.properties: sdk.dir=$ANDROID_HOME" > local.properties

gradle assembleRelease --no-daemon
ls -lh app/build/outputs/apk/release/*.apk
echo "[✓] 完成。安装：adb install -r app/build/outputs/apk/release/app-release.apk"

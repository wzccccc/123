#!/usr/bin/env bash
# 把整个工程打成一个 tar.gz，方便发到电脑。
# 用法（手机端任意终端 / 电脑上都能跑）：
#   bash tools/pack.sh                     # 默认输出 /sdcard/Download/chaoxing-ai.tar.gz
#   bash tools/pack.sh /tmp/cxai.tar.gz    # 指定输出路径
set -uo pipefail

OUT="${1:-/sdcard/Download/chaoxing-ai.tar.gz}"
SRC="$(cd "$(dirname "$0")/.." && pwd)"
PARENT="$(dirname "$SRC")"
NAME="$(basename "$SRC")"

echo "源目录 : $SRC"
echo "输出   : $OUT"

run() {
  if [ "$(id -u)" = "0" ]; then
    "$@"
  elif command -v su >/dev/null 2>&1; then
    # 手机上没有 root 时通常也能写 /sdcard，先直接试
    "$@" 2>/dev/null || su -c "$(printf '%q ' "$@")"
  else
    "$@"
  fi
}

if run tar czf "$OUT" -C "$PARENT" "$NAME" --exclude=.probe --exclude=.git; then
  echo "[✓] 打包完成"
  run ls -lh "$OUT"
  echo
  echo "下一步：把 $OUT 发到电脑，电脑上解压："
  echo "  tar -xzf $(basename "$OUT")     # Windows 10+ 自带 tar，或用 7-Zip"
else
  echo "[!] 写入 $OUT 失败，改写到 /tmp"
  OUT="/tmp/chaoxing-ai.tar.gz"
  tar czf "$OUT" -C "$PARENT" "$NAME" --exclude=.probe --exclude=.git && ls -lh "$OUT"
  echo "再手动拷贝到可访问的位置，例如：cp $OUT /sdcard/Download/"
fi
